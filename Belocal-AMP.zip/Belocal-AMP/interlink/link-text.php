<?php
defined( 'ABSPATH' ) or die();
if ( ! class_exists( 'nrj_LinkifyText' ) ) :
require_once( dirname( __FILE__ ) . DIRECTORY_SEPARATOR . 'nrj-plugin.php' );

class nrj_LinkifyText extends nrj_Plugin_039 {
	/**
	 * The one true instance.
	 *
	 * @var nrj_LinkifyText
	 */
	private static $instance;
	/**
	 * Get singleton instance.
	 *
	 * @since 1.5
	 */
	public static function get_instance() {
		if ( ! isset( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}
	/**
	 * Constructor.
	 */
	protected function __construct() {
		parent::__construct( '1.7', 'linkify-text', 'nrj', __FILE__, array() );
		register_activation_hook( __FILE__, array( __CLASS__, 'activation' ) );
		return self::$instance = $this;
	}
	/**
	 * Handles activation tasks, such as registering the uninstall hook.
	 */
	public static function activation() {
		register_uninstall_hook( __FILE__, array( __CLASS__, 'uninstall' ) );
	}
	/**
	 * Handles uninstallation tasks, such as deleting plugin options.
	 */
	public static function uninstall() {
		delete_option( 'nrj_linkify_text' );
	}
	/**
	 * Initializes the plugin's configuration and localizable text variables.
	 */
	protected function load_config() {
		$this->name      = __( 'Belocal Interlink', $this->textdomain );
		$this->menu_name = __( 'Belocal Interlink', $this->textdomain );
		$this->config = array(
			'text_to_link' => array( 'input' => 'inline_textarea', 'datatype' => 'hash', 'default' => array(
//                "WordPress"   => "https://wordpress.org",
//                "coffee2code" => "http://coffee2code.com"
            ),
            'allow_html' => true, 'no_wrap' => true, 'input_attributes' => 'rows="15" cols="40"',
            'label' => __( 'Text and Links', $this->textdomain ),
            'help'  => __( 'Define only one text and associated link per line, and don\'t span lines.', $this->textdomain ) . '<br />',
            ),
		);
	}
	/**
	 * Override the plugin framework's register_filters() to actually hook actions and filters.
	 */
	public function register_filters() {
		$filters = apply_filters( 'nrj_linkify_text_filters', array( 'the_content', 'the_excerpt', 'widget_text' ) );
		foreach ( (array) $filters as $filter ) {
			add_filter( $filter, array( $this, 'linkify_text' ), 2 );
		}
	}
	/**
	 * Perform text linkification.
	 *
	 * @param string $text Text to be processed for text linkification
	 * @return string Text with replacements already processed
	 */
	public function linkify_text( $text ) {
		$options         = $this->get_options();
		$text_to_link    = apply_filters( 'nrj_linkify_text', $options['text_to_link'] );
		$mb_regex_encoding = null;
		$text = ' ' . $text . ' ';
		$can_do_mb = function_exists( 'mb_regex_encoding' ) && function_exists( 'mb_ereg_replace' ) && function_exists( 'mb_strlen' );
		if ( ! empty( $text_to_link ) ) {
			// Store original mb_regex_encoding and then set it to UTF-8.
			if ( $can_do_mb ) {
				$mb_regex_encoding = mb_regex_encoding();
				mb_regex_encoding( 'UTF-8' );
			}
			foreach ( $text_to_link as $old_text => $link ) {
                $str = str_replace("&", " ", $old_text);
                $str = preg_replace('/\s+/', ' ',$str);
                $str = trim($str);
                $old_text1 = strtolower ( str_replace(' ', '-', $str) );
				$link = esc_url( home_url('/') ) . $old_text1;
				$new_text = '<a href="' . esc_url( $link ) . '">' . $old_text . '</a>';
				$new_text = apply_filters( 'nrj_linkify_text_linked_text', $new_text, $old_text, $link );
				// Escape user-provided string from having regex characters.
				$old_text = preg_quote( $old_text, '~' );
				// If the string to be linked includes '&', consider '&amp;' and '&#038;' equivalents.
				// Visual editor will convert the former, but users aren't aware of the conversion.
				if ( false !== strpos( $old_text, '&' ) ) {
					$old_text = str_replace( '&', '&(amp;|#038;)?', $old_text );
				}
				$regex = "(?![<\[].*?)\b{$old_text}\b(?![^<>]*?[\]>])";
				// If the text to be replaced has multibyte character(s), use
				// mb_ereg_replace() if possible.
				if ( $can_do_mb && ( strlen( $old_text ) != mb_strlen( $old_text ) ) ) {
					// NOTE: mb_ereg_replace() does not support limiting the number of replacements.
					$text = mb_ereg_replace( $regex, $new_text, $text, $preg_flags );
				} else {
					$text = preg_replace( "~{$regex}~{$preg_flags}", $new_text, $text );
				}
			}
			// Restore original mb_regexp_encoding, if changed.
			if ( $mb_regex_encoding ) {
				mb_regex_encoding( $mb_regex_encoding );
			}
			// Remove links within links
			$text = preg_replace( "#(<a [^>]+>)(.*)<a [^>]+>([^<]*)</a>([^>]*)</a>#iU", "$1$2$3$4</a>" , $text );
		}
		return trim( $text );
	}
} // end nrj_LinkifyText
nrj_LinkifyText::get_instance();
endif; // end if !class_exists()