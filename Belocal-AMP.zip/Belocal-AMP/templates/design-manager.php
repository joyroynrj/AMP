<?php
if ( is_customize_preview() ) {
	// Load all the elements in the customizer as we want all the elements in design-manager
	add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_the_title' );
	add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_meta_info' );
	add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_featured_image' );
	add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_the_content' );
	add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_meta_taxonomy' );
	add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_social_icons' );
	add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_related_posts' );
}

	$data = get_option( 'seomasternrj_design' );

	// Adding default Value
	if ($data['elements'] == '') {
	 	$data['elements'] = "meta_info:1,title:1,featured_image:1,content:1,meta_taxonomy:1,social_icons:1,comments:1,related_posts:1";
	}

	if( isset( $data['elements'] ) || ! empty( $data['elements'] ) ){
		$options = explode( ',', $data['elements'] );
	};

	if ($options): foreach ($options as $key=>$value) {
		if ( ! is_customize_preview() ) {
			switch ($value) {
				case 'title:1':
						add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_the_title' );
						break;
				case 'meta_info:1':
						add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_meta_info' );
						break;
				case 'featured_image:1':
						add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_featured_image' );
						break;
				case 'content:1':
						add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_the_content' );
						break;
				case 'meta_taxonomy:1':
						add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_meta_taxonomy' );
						break;
				case 'social_icons:1':
						add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_social_icons' );
						define('SEOMASTERNRJ_DM_SOCIAL_CHECK','true');
						break;
				case 'related_posts:1':
						add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_related_posts' );
						break;
				case 'comments:0':
						add_filter( 'seomasternrj_design_elements', 'seomasternrj_add_element_simple_comment_button' );
						break;
			}
		}
	}
	endif;


// Design Selector

add_action('pre_amp_render_post','seomasternrj_stylesheet_file_insertion', 12 );
function seomasternrj_stylesheet_file_insertion() {

        // Add StyleSheet
        require SEOMASTERNRJ_PLUGIN_DIR . 'templates/design-manager/style.php';
}

// Post Title
function seomasternrj_add_element_the_title( $meta_parts ) {
	$meta_parts[] = 'seomasternrj-the-title';
	return $meta_parts;
}

add_filter( 'amp_post_template_file', 'seomasternrj_design_element_the_title', 10, 3 );

function seomasternrj_design_element_the_title( $file, $type, $post ) {
	if ( 'seomasternrj-the-title' === $type ) {
		$file = SEOMASTERNRJ_PLUGIN_DIR . 'templates/design-manager/elements/title.php' ;
	}
	return $file;
}


// Meta Info
function seomasternrj_add_element_meta_info( $meta_parts ) {
	$meta_parts[] = 'seomasternrj-meta-info';
	return $meta_parts;
}

add_filter( 'amp_post_template_file', 'seomasternrj_design_element_meta_info', 10, 3 );

function seomasternrj_design_element_meta_info( $file, $type, $post ) {
	if ( 'seomasternrj-meta-info' === $type ) {
		$file = SEOMASTERNRJ_PLUGIN_DIR . 'templates/design-manager/elements/meta-info.php' ;
	}
	return $file;
}


// Featured Image
function seomasternrj_add_element_featured_image( $meta_parts ) {
	$meta_parts[] = 'seomasternrj-featured-image';
	return $meta_parts;
}

add_filter( 'amp_post_template_file', 'seomasternrj_design_element_featured_image', 10, 3 );

function seomasternrj_design_element_featured_image( $file, $type, $post ) {
	if ( 'seomasternrj-featured-image' === $type ) {
		$file = SEOMASTERNRJ_PLUGIN_DIR . 'templates/design-manager/elements/featured-image.php';
	}
	return $file;
}


// The Content
function seomasternrj_add_element_the_content( $meta_parts ) {
	$meta_parts[] = 'seomasternrj-the-content';
	return $meta_parts;
}

add_filter( 'amp_post_template_file', 'seomasternrj_design_element_the_content', 10, 3 );

function seomasternrj_design_element_the_content( $file, $type, $post ) {
	if ( 'seomasternrj-the-content' === $type ) {
		$file = SEOMASTERNRJ_PLUGIN_DIR . 'templates/design-manager/elements/content.php';
	}
	return $file;
}

// Meta Texonomy
function seomasternrj_add_element_meta_taxonomy( $meta_parts ) {
	$meta_parts[] = 'seomasternrj-meta-taxonomy';
	return $meta_parts;
}
add_filter( 'amp_post_template_file', 'seomasternrj_design_element_meta_taxonomy', 10, 3 );

function seomasternrj_design_element_meta_taxonomy( $file, $type, $post ) {
	if ( 'seomasternrj-meta-taxonomy' === $type ) {
		$file = SEOMASTERNRJ_PLUGIN_DIR . 'templates/design-manager/elements/meta-taxonomy.php';
	}
	return $file;
}

// Social Icons
function seomasternrj_add_element_social_icons( $meta_parts ) {
	$meta_parts[] = 'seomasternrj-social-icons';
	return $meta_parts;
}
add_filter( 'amp_post_template_file', 'seomasternrj_design_element_social_icons', 10, 3 );

function seomasternrj_design_element_social_icons( $file, $type, $post ) {
	if ( 'seomasternrj-social-icons' === $type ) {
		$file = SEOMASTERNRJ_PLUGIN_DIR . 'templates/design-manager/elements/social-icons.php';
	}
	return $file;
}





// simple comment button
function seomasternrj_add_element_simple_comment_button( $meta_parts ) {
	$meta_parts[] = 'seomasternrj-simple-comment-button';
	return $meta_parts;
}
add_filter( 'amp_post_template_file', 'seomasternrj_design_element_simple_comment_button', 10, 3 );

function seomasternrj_design_element_simple_comment_button( $file, $type, $post ) {
	if ( 'seomasternrj-simple-comment-button' === $type ) {
//		$file = SEOMASTERNRJ_PLUGIN_DIR . 'templates/design-manager/elements/simple-comment-button.php';
	}
	return $file;
}

// Related Posts
function seomasternrj_add_element_related_posts( $meta_parts ) {
	$meta_parts[] = 'seomasternrj-related-posts';
	return $meta_parts;
}
add_filter( 'amp_post_template_file', 'seomasternrj_design_element_related_posts', 10, 3 );

function seomasternrj_design_element_related_posts( $file, $type, $post ) {
	if ( 'seomasternrj-related-posts' === $type ) {
		$file = SEOMASTERNRJ_PLUGIN_DIR . 'templates/design-manager/elements/related-posts.php';
	}
	return $file;
}
?>