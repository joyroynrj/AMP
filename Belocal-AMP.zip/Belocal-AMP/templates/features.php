<?php
/* This file will contain all the Extra FEATURES.

*/
// Adding AMP-related things to the main theme
	global $redux_builder_amp;


	// 0.9. AMP Design Manager Files
	require 'design-manager.php';
	// Custom AMP Content
	require 'custom-amp-content.php';

//0.

// define('SEOMASTERNRJ_COMMENTS_PER_PAGE', $redux_builder_amp['seomasternrj-number-of-comments'] );

	// 1. Add Home REL canonical
	// Add AMP rel-canonical for home and archive pages

	add_action('amp_init','seomasternrj_allow_homepage');
	function seomasternrj_allow_homepage() {
		add_action( 'wp', 'seomasternrj_add_endpoint_actions' );
	}

	function seomasternrj_add_endpoint_actions() {
		// if ( is_home() ) {

			$seomasternrj_is_amp_endpoint = seomasternrj_is_amp_endpoint();

			if ( $seomasternrj_is_amp_endpoint ) {
				amp_prepare_render();
			} else {
				add_action( 'wp_head', 'seomasternrj_home_archive_rel_canonical' );
			}

		// }
	}

	function seomasternrj_home_archive_rel_canonical() {
		global $redux_builder_amp;
		global $wp;
	    if( is_attachment() ) {
        return;
	    }
	    if( is_home() && !$redux_builder_amp['seomasternrj-homepage-on-off-support'] ) {
        return;
	    }
	    if( is_front_page() && ! $redux_builder_amp['seomasternrj-homepage-on-off-support'] ) {
        return;
	    }
	    if ( is_archive() && !$redux_builder_amp['seomasternrj-archive-support'] ) {
				return;
			}
      if( is_page() && !$redux_builder_amp['amp-on-off-for-all-pages'] ) {
				return;
			}
			if( is_front_page() &&  $wp->query_vars['cpage'] >= '2' ) {
				return;
			}
			if( is_singular() &&  $wp->query_vars['cpage'] >= '2' ) {
				return;
			}

	    if ( is_home()  || is_front_page() || is_archive() ){
	        global $wp;
	        $current_archive_url = home_url( $wp->request );
	        $amp_url = trailingslashit($current_archive_url).'amp';

	    } else {
	      $amp_url = amp_get_permalink( get_queried_object_id() );
	    }

	        global $post;
	        $seomasternrj_amp_post_on_off_meta = get_post_meta( get_the_ID(),'seomasternrj-amp-on-off',true);
	        if( $seomasternrj_amp_post_on_off_meta === 'hide-amp' ) {
	          //dont Echo anything
	        } else {
				$supported_types = array('post','page');

				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
				if( is_plugin_active( 'amp-custom-post-type/amp-custom-post-type.php' ) ) {
					if ( $redux_builder_amp['seomasternrj-custom-type'] ) {
						foreach($redux_builder_amp['seomasternrj-custom-type'] as $custom_post){
							$supported_types[] = $custom_post;
						}
					}
				}

				include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
				if( is_plugin_active( 'amp-woocommerce/amp-woocommerce.php' ) ) {
					if( !in_array("product", $supported_types) ){
						$supported_types[]= 'product';
					}
				}

				$type = get_post_type();
				$supported_amp_post_types = in_array( $type , $supported_types );

				if ( is_home() && $wp->query_vars['paged'] >= '2' ) {
					$new_url =  home_url('/');
					$new_url = $new_url . SEOMASTERNRJ_AMP_QUERY_VAR . '/' . $wp->request ;
					$amp_url = $new_url ;
				}
				if ( is_archive() && $wp->query_vars['paged'] >= '2' ) {
					$new_url 		=  home_url('/');
				 	$category_path 	= $wp->request;
				 	$explode_path  	= explode("/",$category_path);
				 	$inserted 		= array(SEOMASTERNRJ_AMP_QUERY_VAR);
					array_splice( $explode_path, -2, 0, $inserted );
					$impode_url = implode('/', $explode_path);

					$amp_url = $new_url . $impode_url ;
				}

		        if( is_search() ) {
		          $current_search_url =trailingslashit(get_home_url())."?amp=1&s=".get_search_query();
			          if ( $wp->query_vars['paged'] >= '2' ) {
			          	$current_search_url =trailingslashit(get_home_url()) . $wp->request .'/'."?amp=1&s=".get_search_query();
			          }
		          $amp_url = untrailingslashit($current_search_url);
		        }

				if( $supported_amp_post_types) {
					printf( '<link rel="amphtml" href="%s" />', esc_url( $amp_url ) );
				}

	        }
	} //end of seomasternrj_home_archive_rel_canonical()


	// Remove default wordpress rel canonical
	add_filter('amp_frontend_show_canonical','seomasternrj_remove_default_canonical');
	if (! function_exists('seomasternrj_remove_default_canonical') ) {
		function seomasternrj_remove_default_canonical() {
			return false;
		}
	}

	// 2. Custom Design

	// Add Homepage AMP file code
	add_filter( 'amp_post_template_file', 'seomasternrj_custom_template', 10, 3 );
	function seomasternrj_custom_template( $file, $type, $post ) {
	   	// Custom Homepage and Archive file

        global $redux_builder_amp;
        // Homepage and FrontPage
        if($redux_builder_amp['amp-frontpage-select-option'] == 0)  {
            if ( is_home() ) {
                if ( 'single' === $type ) {
                	$file = SEOMASTERNRJ_PLUGIN_DIR . '/templates/design-manager/index.php';
                }
            }
        } elseif ($redux_builder_amp['amp-frontpage-select-option'] == 1) {
            if ( is_home() ) {
                if ( 'single' === $type ) {
                    $file = SEOMASTERNRJ_PLUGIN_DIR . '/templates/design-manager/frontpage.php';
                }
            }

        }

        // Archive Pages
        if ( is_archive() && $redux_builder_amp['seomasternrj-archive-support'] )  {

            $file = SEOMASTERNRJ_PLUGIN_DIR . '/templates/design-manager/archive.php';
        }


				// Search pages
      	if ( is_search() &&
						( $redux_builder_amp['amp-design-1-search-feature'] ||
						  $redux_builder_amp['amp-design-2-search-feature'] ||
							$redux_builder_amp['amp-design-3-search-feature'] )
						)  {
            $file = SEOMASTERNRJ_PLUGIN_DIR . '/templates/design-manager/search.php';
        }


		// Custom Single file
	    if ( is_single() || is_page() ) {

			if('single' === $type && !('product' === $post->post_type )) {
			 	$file = SEOMASTERNRJ_PLUGIN_DIR . '/templates/design-manager/single.php';
		 	}
		}
	    return $file;
	}

	// 3. Custom Style files
	add_filter( 'amp_post_template_file', 'seomasternrj_set_custom_style', 10, 3 );
	function seomasternrj_set_custom_style( $file, $type, $post ) {
		if ( 'style' === $type ) {
			$file = '';
		}
		return $file;
	}

	//3.5
	add_filter( 'amp_post_template_file', 'seomasternrj_empty_filter', 10, 3 );
	function seomasternrj_empty_filter( $file, $type, $post ) {
		if ( 'empty-filter' === $type ) {
			$file = SEOMASTERNRJ_PLUGIN_DIR . '/templates/design-manager/empty-filter.php';
		}
		return $file;
	}

	// 4. Custom Header files
	add_filter( 'amp_post_template_file', 'seomasternrj_custom_header', 10, 3 );
	function seomasternrj_custom_header( $file, $type, $post ) {
		if ( 'header-bar' === $type ) {
			$file = SEOMASTERNRJ_PLUGIN_DIR . '/templates/design-manager/header-bar.php';
		}
		return $file;
	}

	// 4.1 Custom Meta-Author files
	add_filter( 'amp_post_template_file', 'seomasternrj_set_custom_meta_author', 10, 3 );
	function seomasternrj_set_custom_meta_author( $file, $type, $post ) {
		if ( 'meta-author' === $type ) {
			$file = SEOMASTERNRJ_PLUGIN_DIR . '/templates/design-manager/empty-filter.php';
		}
		return $file;
	}
	// 4.2 Custom Meta-Taxonomy files
	add_filter( 'amp_post_template_file', 'seomasternrj_set_custom_meta_taxonomy', 10, 3 );
	function seomasternrj_set_custom_meta_taxonomy( $file, $type, $post ) {
		if ( 'meta-taxonomy' === $type ) {
			$file = SEOMASTERNRJ_PLUGIN_DIR . 'templates/design-manager/empty-filter.php';
		}
		return $file;
	}

	// 4.5 Added hook to add more layout.
	do_action('seomasternrj_after_features_include');


	// 5.  Customize with Width of the site
	add_filter( 'amp_content_max_width', 'seomasternrj_change_content_width' );
	function seomasternrj_change_content_width( $content_max_width ) {
		return 1000;
	}

	// 6. Add required Javascripts for extra AMP features
	add_action('amp_post_template_head','seomasternrj_register_additional_scripts', 20);
	function seomasternrj_register_additional_scripts() {
		global $redux_builder_amp;
		if( is_page() ) { ?>
			<script async custom-element="amp-form" src="https://cdn.ampproject.org/v0/amp-form-0.1.js"></script>
		<?php } ?>

<!-- 		<//?php if( $redux_builder_amp['enable-single-social-icons'] == true || SEOMASTERNRJ_DM_SOCIAL_CHECK === 'true' )  { ?>
			<//?php if( is_singular() ) {
							if( is_socialshare_or_socialsticky_enabled_in_seomasternrj() ) { ?>
				<script async custom-element="amp-social-share" src="https://cdn.ampproject.org/v0/amp-social-share-0.1.js"></script>
			<//?php   }
						}
		} ?> -->
		<?php if($redux_builder_amp['amp-frontpage-select-option'] == 1)  { ?>
			<?php if( $redux_builder_amp['enable-single-social-icons'] == true || SEOMASTERNRJ_DM_SOCIAL_CHECK === 'true' )  {
							if( is_home() ) {
								if( is_socialshare_or_socialsticky_enabled_in_seomasternrj() ) { ?>
								<script async custom-element="amp-social-share" src="https://cdn.ampproject.org/v0/amp-social-share-0.1.js"></script>
					<?php }
							}
						}
					}
		// Check if any of the ads are enabled then only load ads script
		//	moved this code to its own function and done the AMP way
	}
	// 6.1 Adding Analytics Scripts
	add_action('amp_post_template_head','seomasternrj_register_analytics_script', 20);
	function seomasternrj_register_analytics_script(){ ?>
		<script async custom-element="amp-analytics" src="https://cdn.ampproject.org/v0/amp-analytics-0.1.js"></script>
		<?php

	}

	add_filter( 'amp_post_template_data', 'seomasternrj_add_amp_related_scripts', 20 );
	function seomasternrj_add_amp_related_scripts( $data ) {
		global $redux_builder_amp;
		// Adding Sidebar Script
		if ( empty( $data['amp_component_scripts']['amp-sidebar'] ) ) {
			$data['amp_component_scripts']['amp-sidebar'] = 'https://cdn.ampproject.org/v0/amp-sidebar-0.1.js';
		}

		return $data;
	}

	// 7. Footer for AMP Pages
	add_filter( 'amp_post_template_file', 'seomasternrj_custom_footer', 10, 3 );
	function seomasternrj_custom_footer( $file, $type, $post ) {
		if ( 'footer' === $type ) {
			$file = SEOMASTERNRJ_PLUGIN_DIR . '/templates/design-manager/footer.php';
		}
		return $file;
	}






	// 10. Analytics Area
		add_action('amp_post_template_footer','seomasternrj_analytics',11);
		function seomasternrj_analytics() {

			// 10.1 Analytics Support added for Google Analytics
				global $redux_builder_amp;
				if ( $redux_builder_amp['amp-analytics-select-option']=='1' ){ ?>
						<amp-analytics type="googleanalytics" id="analytics1">
							<script type="application/json">
							{
							  "vars": {
							    "account": "<?php global $redux_builder_amp; echo $redux_builder_amp['ga-feild']; ?>"
							  },
							  "triggers": {
							    "trackPageview": {
							      "on": "visible",
							      "request": "pageview"
							    }
							  }
							}
							</script>
						</amp-analytics>
						<?php
					}//code ends for supporting Google Analytics

			// 10.2 Analytics Support added for segment.com
				if ( $redux_builder_amp['amp-analytics-select-option']=='2' ) { ?>
						<amp-analytics type="segment">
							<script>
							{
							  "vars": {
							    "writeKey": "<?php global $redux_builder_amp; echo $redux_builder_amp['sa-feild']; ?>",
									"name": "<?php echo the_title(); ?>"
							  }
							}
							</script>
						</amp-analytics>
						<?php
					}

			// 10.3 Analytics Support added for Piwik
				if( $redux_builder_amp['amp-analytics-select-option']=='3' ) { ?>
						<amp-pixel src="<?php global $redux_builder_amp; echo $redux_builder_amp['pa-feild']; ?>"></amp-pixel>
				<?php }

				// 10.4 Analytics Support added for quantcast
					if ( $redux_builder_amp['amp-analytics-select-option']=='4' ) { ?>
							<amp-analytics type="quantcast">
								<script type="application/json">
								{
								  "vars": {
								    "pcode": "<?php echo $redux_builder_amp['amp-quantcast-analytics-code']; ?>",
										"labels": [ "AMPProject" ]
								  }
								}
								</script>
							</amp-analytics>
							<?php
						}

				// 10.5 Analytics Support added for comscore
					if ( $redux_builder_amp['amp-analytics-select-option']=='5' ) { ?>
							<amp-analytics type="comscore">
								<script type="application/json">
								{
								  "vars": {
								    "c1": "<?php echo $redux_builder_amp['amp-comscore-analytics-code-c1']; ?>",
								    "c2": "<?php echo $redux_builder_amp['amp-comscore-analytics-code-c2']; ?>"
								  }
								}
								</script>
							</amp-analytics>
							<?php
						}


		}//analytics function ends here

	// 11. Strip unwanted codes and tags from the_content
		add_action( 'pre_amp_render_post','seomasternrj_strip_invalid_content');
		function seomasternrj_strip_invalid_content() {
			add_filter( 'the_content', 'seomasternrj_the_content_filter', 2 );
		}
		function seomasternrj_the_content_filter( $content ) {
				 $content = preg_replace('/property=[^>]*/', '', $content);
				 $content = preg_replace('/vocab=[^>]*/', '', $content);
				//  $content = preg_replace('/type=[^>]*/', '', $content);
				 $content = preg_replace('/value=[^>]*/', '', $content);
				//  $content = preg_replace('/date=[^>]*/', '', $content);
				 $content = preg_replace('/noshade=[^>]*/', '', $content);
				 $content = preg_replace('/contenteditable=[^>]*/', '', $content);
				//  $content = preg_replace('/time=[^>]*/', '', $content);
				 $content = preg_replace('/non-refundable=[^>]*/', '', $content);
				 $content = preg_replace('/security=[^>]*/', '', $content);
				 $content = preg_replace('/deposit=[^>]*/', '', $content);
				 $content = preg_replace('/for=[^>]*/', '', $content);
				 $content = preg_replace('/nowrap="nowrap"/', '', $content);
				 $content = preg_replace('#<comments-count.*?>(.*?)</comments-count>#i', '', $content);
				 $content = preg_replace('#<time.*?>(.*?)</time>#i', '', $content);
				 $content = preg_replace('#<badge.*?>(.*?)</badge>#i', '', $content);
				 $content = preg_replace('#<plusone.*?>(.*?)</plusone>#i', '', $content);
				 $content = preg_replace('#<col.*?>#i', '', $content);
				 $content = preg_replace('#<table.*?>#i', '<table width="100%">', $content);
				 /* Removed So Inline style can work
				 $content = preg_replace('#<style scoped.*?>(.*?)</style>#i', '', $content); */
				 $content = preg_replace('/href="javascript:void*/', ' ', $content);
				 $content = preg_replace('/<script[^>]*>.*?<\/script>/i', '', $content);
				 //for removing attributes within html tags
				 $content = preg_replace('/(<[^>]+) onclick=".*?"/', '$1', $content);
				 /* Removed So Inline style can work
				 $content = preg_replace('/(<[^>]+) style=".*?"/', '$1', $content);
				 */
				 $content = preg_replace('/(<[^>]+) rel=".*?"/', '$1', $content);
				 $content = preg_replace('/(<[^>]+) ref=".*?"/', '$1', $content);
				 $content = preg_replace('/(<[^>]+) date=".*?"/', '$1', $content);
				 $content = preg_replace('/(<[^>]+) time=".*?"/', '$1', $content);
				 $content = preg_replace('/(<[^>]+) imap=".*?"/', '$1', $content);
				 $content = preg_replace('/(<[^>]+) date/', '$1', $content);
				 $content = preg_replace('/(<[^>]+) spellcheck/', '$1', $content);
				 $content = preg_replace('/<font(.*?)>(.*?)<\/font>/', '$2', $content);

				 //removing scripts and rel="nofollow" from Body and from divs
				 //issue #268
				 $content = str_replace(' rel="nofollow"',"",$content);
				 $content = preg_replace('/<script[^>]*>.*?<\/script>/i', '', $content);
				// simpy add more elements to simply strip tag but not the content as so
				// Array ("p","font");
				$tags_to_strip = Array("thrive_headline","type","date","time","place","state","city" );
				foreach ($tags_to_strip as $tag)
				{
				   $content = preg_replace("/<\\/?" . $tag . "(.|\\s)*?>/",'',$content);
				}
				// regex on steroids from here on
				 // issue #420
				 $content = preg_replace("/<div\s(class=.*?)(href=((".'"|'."'".')(.*?)("|'."'".')))\s(width=("|'."'".')(.*?)("|'."'"."))>(.*)<\/div>/i", '<div $1>$11</div>', $content);
				 $content = preg_replace('/<like\s(.*?)>(.*)<\/like>/i', '', $content);
				 $content = preg_replace('/<g:plusone\s(.*?)>(.*)<\/g:plusone>/i', '', $content);
				 $content = preg_replace('/imageanchor="1"/i', '', $content);
				 $content = preg_replace('/<plusone\s(.*?)>(.*?)<\/plusone>/', '', $content);

				//				 $content = preg_replace('/<img*/', '<amp-img', $content); // Fallback for plugins
				return $content;
		}


	// 11.1 Strip unwanted codes and tags from wp_footer for better compatibility with Plugins
		if ( ! is_customize_preview() ) {
			add_action( 'pre_amp_render_post','seomasternrj_strip_invalid_content_footer');
		}
		function seomasternrj_strip_invalid_content_footer() {
			add_filter( 'wp_footer', 'seomasternrj_the_content_filter_footer', 1 );
		}
		function seomasternrj_the_content_filter_footer( $content ) {
            remove_all_actions('wp_footer');
				return $content;
		}

	// 11.5 Strip unwanted codes the_content of Frontpage
    add_action( 'pre_amp_render_post','seomasternrj_strip_invalid_content_frontpage');
        function seomasternrj_strip_invalid_content_frontpage(){
            if ( is_front_page() || is_home() ) {
			add_filter( 'the_content', 'seomasternrj_the_content_filter_frontpage', 20 );
            }
		}
		function seomasternrj_the_content_filter_frontpage( $content ) {
				 $content = preg_replace('/<img*/', '<amp-img', $content); // Fallback for plugins
				return $content;
		}

		// 12. Add Logo URL in the structured metadata
	    add_filter( 'amp_post_template_metadata', 'seomasternrj_update_metadata', 10, 2 );
	    function seomasternrj_update_metadata( $metadata, $post ) {
	        global $redux_builder_amp;

	        if (! empty( $redux_builder_amp['opt-media']['url'] ) ) {
	          $structured_data_main_logo = $redux_builder_amp['opt-media']['url'];
	        }

	        if (! empty( $redux_builder_amp['amp-structured-data-logo']['url'] ) ) {
	          $structured_data_logo = $redux_builder_amp['amp-structured-data-logo']['url'];
	        }
	        if ( $structured_data_logo ) {
	          $structured_data_logo = $structured_data_logo;
	        } else {
	          $structured_data_logo = $structured_data_main_logo;
	        }
	        $metadata['publisher']['logo'] = array(
	          '@type'   => 'ImageObject',
	          'url'     =>  $structured_data_logo ,
	          'height'  => 36,
	          'width'   => 190,
	        );

	        //code for adding 'description' meta from Yoast SEO

	        if($redux_builder_amp['seomasternrj-seo-yoast-description']){
	         if ( class_exists('WPSEO_Frontend') ) {
	           $front = WPSEO_Frontend::get_instance();
	           $desc = $front->metadesc( false );
	           if ( $desc ) {
	             $metadata['description'] = $desc;
	           }

	           // Code for Custom Frontpage Yoast SEO Description
	           $post_id = $redux_builder_amp['amp-frontpage-select-option-pages'];
	           if ( class_exists('WPSEO_Meta') ) {
	             $custom_fp_desc = WPSEO_Meta::get_value('metadesc', $post_id );
	             if ( is_home() && $redux_builder_amp['amp-frontpage-select-option'] ) {
	               if ( $custom_fp_desc ) {
	                 $metadata['description'] = $custom_fp_desc;
	               } else {
	                 unset( $metadata['description'] );
	               }
	             }
	           }
	         }
	        }
	        //End of code for adding 'description' meta from Yoast SEO
	        return $metadata;
	    }


	// 13. Add Custom Placeholder Image for Structured Data.
	// if there is no image in the post, then use this image to validate Structured Data.
	add_filter( 'amp_post_template_metadata', 'seomasternrj_update_metadata_featured_image', 10, 2 );
	function seomasternrj_update_metadata_featured_image( $metadata, $post ) {
			global $redux_builder_amp;
			global $post;
			$post_id = get_the_ID() ;
			$post_image_id = get_post_thumbnail_id( $post_id );
			$structured_data_image = wp_get_attachment_image_src( $post_image_id, 'full' );
			$post_image_check = $structured_data_image;

			if ( $post_image_check == false) {
				// if (! empty( $redux_builder_amp['amp-structured-data-placeholder-image']['url'] ) ) {
				// 	$structured_data_image_url = $redux_builder_amp['amp-structured-data-placeholder-image']['url'];
				// }
					// $structured_data_image = $structured_data_image_url;
					$structured_data_height = intval($redux_builder_amp['amp-structured-data-placeholder-image-height']);
					$structured_data_width = intval($redux_builder_amp['amp-structured-data-placeholder-image-width']);

					$metadata['image'] = array(
						'@type' 	=> 'ImageObject',
						'url' 		=> $structured_data_image ,
						'height' 	=> $structured_data_height,
						'width' 	=> $structured_data_width,
					);
			}
			// Custom Structured Data information for Archive, Categories and tag pages.
			if ( is_archive() ) {
					$structured_data_image = $redux_builder_amp['amp-structured-data-placeholder-image']['url'];
					$structured_data_height = intval($redux_builder_amp['amp-structured-data-placeholder-image-height']);
					$structured_data_width = intval($redux_builder_amp['amp-structured-data-placeholder-image-width']);

					$structured_data_archive_title 	= "Archived Posts";
					$structured_data_author				=  get_userdata( 1 );
							if ( $structured_data_author ) {
								$structured_data_author 		= $structured_data_author->display_name ;
							} else {
								$structured_data_author 		= "admin";
							}

					$metadata['image'] = array(
						'@type' 	=> 'ImageObject',
						'url' 		=> $structured_data_image ,
						'height' 	=> $structured_data_height,
						'width' 	=> $structured_data_width,
					);
					$metadata['author'] = array(
						'@type' 	=> 'Person',
						'name' 		=> $structured_data_author ,
					);
					$metadata['headline'] = $structured_data_archive_title;
			}

			if ( $metadata['image']['width'] < 696 ) {
	 			$metadata['image']['width'] = 700 ;
     	}

			return $metadata;
	}

// 14. Adds a meta box to the post editing screen for AMP on-off on specific pages.
/**
 * Adds a meta box to the post editing screen for AMP on-off on specific pages
*/
function seomasternrj_title_custom_meta() {
  global $redux_builder_amp;
    $args = array(
       'public'   => true,
    );

    $output = 'names'; // 'names' or 'objects' (default: 'names')
    $operator = 'and'; // 'and' or 'or' (default: 'and')

    $post_types = get_post_types( $args, $output, $operator );

    if ( $post_types ) { // If there are any custom public post types.

        foreach ( $post_types  as $post_type ) {

          if( $post_type == 'amp-cta' ) {
							continue;
          }

          if( $post_type !== 'page' ) {
            add_meta_box( 'seomasternrj_title_meta', __( 'Show AMP for Current Page?' ), 'seomasternrj_title_callback', $post_type,'side' );
          }

          if( $redux_builder_amp['amp-on-off-for-all-pages'] && $post_type == 'page' ) {
              add_meta_box( 'seomasternrj_title_meta', __( 'Show AMP for Current Page?' ), 'seomasternrj_title_callback','page','side' );
          }

        }
    }
}
add_action( 'add_meta_boxes', 'seomasternrj_title_custom_meta' );

/**
 * Outputs the content of the meta box for AMP on-off on specific pages
 */
function seomasternrj_title_callback( $post ) {
    wp_nonce_field( basename( __FILE__ ), 'seomasternrj_title_nonce' );
    $seomasternrj_stored_meta = get_post_meta( $post->ID );

    	// TODO: Move the data storage code, to Save meta Box area as it is not a good idea to update an option everytime, try adding this code inside seomasternrj_title_meta_save()
    	// This code needs a rewrite.
		if ( $seomasternrj_stored_meta['seomasternrj-amp-on-off'][0] == 'hide-amp') {
			$exclude_post_value = get_option('seomasternrj_exclude_post');
			if ( $exclude_post_value == null ) {
				$exclude_post_value[] = 0;
			}
			if ( $exclude_post_value ) {
				if ( ! in_array( $post->ID, $exclude_post_value ) ) {
					$exclude_post_value[] = $post->ID;
					update_option('seomasternrj_exclude_post', $exclude_post_value);
				}
			}
		} else {
			$exclude_post_value = get_option('seomasternrj_exclude_post');
			if ( $exclude_post_value == null ) {
				$exclude_post_value[] = 0;
			}
			if ( $exclude_post_value ) {
				if ( in_array( $post->ID, $exclude_post_value ) ) {
					$exclude_ids = array_diff($exclude_post_value, array($post->ID) );
					update_option('seomasternrj_exclude_post', $exclude_ids);
				}
			}

		}
        ?>
    <p>
        <div class="prfx-row-content">
            <label for="meta-radio-one">
                <input type="radio" name="seomasternrj-amp-on-off" id="meta-radio-one" value="default"  checked="checked" <?php if ( isset ( $seomasternrj_stored_meta['seomasternrj-amp-on-off'] ) ) checked( $seomasternrj_stored_meta['seomasternrj-amp-on-off'][0], 'default' ); ?>>
                <?php _e( 'Show' )?>
            </label>
            <label for="meta-radio-two">
                <input type="radio" name="seomasternrj-amp-on-off" id="meta-radio-two" value="hide-amp" <?php if ( isset ( $seomasternrj_stored_meta['seomasternrj-amp-on-off'] ) ) checked( $seomasternrj_stored_meta['seomasternrj-amp-on-off'][0], 'hide-amp' ); ?>>
                <?php _e( 'Hide' )?>
            </label>
        </div>
    </p>
    <?php
}

/**
 * Saves the custom meta input for AMP on-off on specific pages
 */
function seomasternrj_title_meta_save( $post_id ) {

    // Checks save status
    $is_autosave = wp_is_post_autosave( $post_id );
    $is_revision = wp_is_post_revision( $post_id );
    $is_valid_nonce = ( isset( $_POST[ 'seomasternrj_title_nonce' ] ) && wp_verify_nonce( $_POST[ 'seomasternrj_title_nonce' ], basename( __FILE__ ) ) ) ? 'true' : 'false';

    // Exits script depending on save status
    if ( $is_autosave || $is_revision || !$is_valid_nonce ) {
        return;
    }

    // Checks for radio buttons and saves if needed
    if( isset( $_POST[ 'seomasternrj-amp-on-off' ] ) ) {
        $seomasternrj_amp_status = sanitize_text_field( $_POST[ 'seomasternrj-amp-on-off' ] );
        update_post_meta( $post_id, 'seomasternrj-amp-on-off', $seomasternrj_amp_status );
    }

}
add_action( 'save_post', 'seomasternrj_title_meta_save' );

add_filter('amp_frontend_show_canonical','seomasternrj_hide_amp_for_specific_pages');
function seomasternrj_hide_amp_for_specific_pages($input){
		global $post;
		$seomasternrj_amp_status = get_post_meta($post->ID, 'seomasternrj-amp-on-off', true);
		if ( $seomasternrj_amp_status == 'hide-amp' ) {
			$input = false;
		}
		return $input;
}

// 15. Disable New Relic's extra script that its adds in AMP pages.
add_action( 'amp_post_template_data', 'seomasternrj_disable_new_relic_scripts' );
if ( ! function_exists('seomasternrj_disable_new_relic_scripts') ) {
		function seomasternrj_disable_new_relic_scripts( $data ) {
			if ( ! function_exists( 'newrelic_disable_autorum' ) ) {
				return $data;
			}
			if ( function_exists( 'seomasternrj_is_amp_endpoint' ) && seomasternrj_is_amp_endpoint() ) {
				newrelic_disable_autorum();
			}
			return $data;
		}
}

// 16. Remove Unwanted Scripts
if ( function_exists( 'seomasternrj_is_amp_endpoint' ) && seomasternrj_is_amp_endpoint() ) {
	add_action( 'wp_enqueue_scripts', 'seomasternrj_remove_unwanted_scripts',20 );
}
function seomasternrj_remove_unwanted_scripts() {
  wp_dequeue_script('jquery');
}
// Remove Print Scripts and styles
function seomasternrj_remove_print_scripts() {
		if ( seomasternrj_is_amp_endpoint() ) {

		    function seomasternrj_remove_all_scripts() {
		        global $wp_scripts;
		        $wp_scripts->queue = array();
		    }
		    add_action('wp_print_scripts', 'seomasternrj_remove_all_scripts', 100);
		    function seomasternrj_remove_all_styles() {
		        global $wp_styles;
		        $wp_styles->queue = array();
		    }
		    add_action('wp_print_styles', 'seomasternrj_remove_all_styles', 100);

				// Remove Print Emoji for Nextgen Gallery support
				remove_action( 'wp_head', 'print_emoji_detection_script', 7 );
				remove_action( 'wp_print_styles', 'print_emoji_styles' );

		}
}
add_action( 'template_redirect', 'seomasternrj_remove_print_scripts' );


// 19. Remove Canonical tags
function seomasternrj_amp_remove_actions() {
    if ( is_home() || is_front_page() || is_archive() || is_search() ) {
        remove_action( 'amp_post_template_head', 'amp_post_template_add_canonical' );
    }
}
add_action( 'amp_post_template_head', 'seomasternrj_amp_remove_actions', 9 );


// 21. Remove Schema data from All In One Schema.org Rich Snippets Plugin
add_action( 'pre_amp_render_post', 'seomasternrj_remove_schema_data' );
function seomasternrj_remove_schema_data() {
	remove_filter('the_content','display_rich_snippet');
    	// Ultimate Social Media PLUS Compatiblity Added
	remove_filter('the_content','sfsi_plus_beforaftereposts');
	remove_filter('the_content','sfsi_plus_beforeafterblogposts');

	// Thrive Content Builder
	$amp_custom_content_enable = get_post_meta( get_the_ID() , 'seomasternrj_custom_content_editor_checkbox', true);
	if ($amp_custom_content_enable == 'yes') {
		remove_filter( 'the_content', 'tve_editor_content', 10 );
	}

}

// 22. Removing author links from comments Issue #180
if( ! function_exists( "disable_comment_author_links" ) ) {
	function seomasternrj_disable_comment_author_links( $author_link ){
		$seomasternrj_is_amp_endpoint = seomasternrj_is_amp_endpoint();
		if ( $seomasternrj_is_amp_endpoint ) {
				return strip_tags( $author_link );
		} else {
			return $author_link;
		}
	}
	add_filter( 'get_comment_author_link', 'seomasternrj_disable_comment_author_links' );
}

// 23. The analytics tag appears more than once in the document. This will soon be an error
remove_action( 'amp_post_template_head', 'quads_amp_add_amp_ad_js');

// 24. Seperate Sticky Single Social Icons
// TO DO: we can directly call social-icons.php instead of below code
add_action('amp_post_template_footer','seomasternrj_sticky_social_icons');
function seomasternrj_sticky_social_icons(){
	global $redux_builder_amp;
	if($redux_builder_amp['enable-single-social-icons'] == true && is_single() )  { ?>
		<div class="sticky_social">
			<?php if($redux_builder_amp['enable-single-facebook-share'] == true)  { ?>
		    	<amp-social-share type="facebook"    data-param-app_id="<?php echo $redux_builder_amp['amp-facebook-app-id']; ?>" width="50" height="28"></amp-social-share>
		  	<?php } ?>
		  	<?php if($redux_builder_amp['enable-single-twitter-share'] == true)  {
          $data_param_data = $redux_builder_amp['enable-single-twitter-share-handle'];?>
          <amp-social-share type="twitter"
                            width="50"
                            height="28"
                            data-param-url="<?php echo wp_get_shortlink() ?>"
                            data-param-text="<?php echo $data_param_data ?> TITLE"
          ></amp-social-share>
		  	<?php } ?>
		  	<?php if($redux_builder_amp['enable-single-gplus-share'] == true)  { ?>
		    	<amp-social-share type="gplus"      width="50" height="28"></amp-social-share>
		  	<?php } ?>
		  	<?php if($redux_builder_amp['enable-single-email-share'] == true)  { ?>
		    	<amp-social-share type="email"      width="50" height="28"></amp-social-share>
		  	<?php } ?>
		  	<?php if($redux_builder_amp['enable-single-pinterest-share'] == true)  { ?>
		    	<amp-social-share type="pinterest"  width="50" height="28"></amp-social-share>
		  	<?php } ?>
		  	<?php if($redux_builder_amp['enable-single-linkedin-share'] == true)  { ?>
		    	<amp-social-share type="linkedin" width="50" height="28"></amp-social-share>
		  	<?php } ?>
		  	<?php if($redux_builder_amp['enable-single-whatsapp-share'] == true)  { ?>
						<a href="whatsapp://send?text=<?php echo get_the_permalink();?>">
						<div class="whatsapp-share-icon">
						    <amp-img src="data:image/svg+xml;utf8;base64,PD94bWwgdmVyc2lvbj0iMS4wIiBlbmNvZGluZz0iaXNvLTg4NTktMSI/Pgo8IS0tIEdlbmVyYXRvcjogQWRvYmUgSWxsdXN0cmF0b3IgMTYuMC4wLCBTVkcgRXhwb3J0IFBsdWctSW4gLiBTVkcgVmVyc2lvbjogNi4wMCBCdWlsZCAwKSAgLS0+CjwhRE9DVFlQRSBzdmcgUFVCTElDICItLy9XM0MvL0RURCBTVkcgMS4xLy9FTiIgImh0dHA6Ly93d3cudzMub3JnL0dyYXBoaWNzL1NWRy8xLjEvRFREL3N2ZzExLmR0ZCI+CjxzdmcgeG1sbnM9Imh0dHA6Ly93d3cudzMub3JnLzIwMDAvc3ZnIiB4bWxuczp4bGluaz0iaHR0cDovL3d3dy53My5vcmcvMTk5OS94bGluayIgdmVyc2lvbj0iMS4xIiBpZD0iQ2FwYV8xIiB4PSIwcHgiIHk9IjBweCIgd2lkdGg9IjUxMnB4IiBoZWlnaHQ9IjUxMnB4IiB2aWV3Qm94PSIwIDAgOTAgOTAiIHN0eWxlPSJlbmFibGUtYmFja2dyb3VuZDpuZXcgMCAwIDkwIDkwOyIgeG1sOnNwYWNlPSJwcmVzZXJ2ZSI+CjxnPgoJPHBhdGggaWQ9IldoYXRzQXBwIiBkPSJNOTAsNDMuODQxYzAsMjQuMjEzLTE5Ljc3OSw0My44NDEtNDQuMTgyLDQzLjg0MWMtNy43NDcsMC0xNS4wMjUtMS45OC0yMS4zNTctNS40NTVMMCw5MGw3Ljk3NS0yMy41MjIgICBjLTQuMDIzLTYuNjA2LTYuMzQtMTQuMzU0LTYuMzQtMjIuNjM3QzEuNjM1LDE5LjYyOCwyMS40MTYsMCw0NS44MTgsMEM3MC4yMjMsMCw5MCwxOS42MjgsOTAsNDMuODQxeiBNNDUuODE4LDYuOTgyICAgYy0yMC40ODQsMC0zNy4xNDYsMTYuNTM1LTM3LjE0NiwzNi44NTljMCw4LjA2NSwyLjYyOSwxNS41MzQsNy4wNzYsMjEuNjFMMTEuMTA3LDc5LjE0bDE0LjI3NS00LjUzNyAgIGM1Ljg2NSwzLjg1MSwxMi44OTEsNi4wOTcsMjAuNDM3LDYuMDk3YzIwLjQ4MSwwLDM3LjE0Ni0xNi41MzMsMzcuMTQ2LTM2Ljg1N1M2Ni4zMDEsNi45ODIsNDUuODE4LDYuOTgyeiBNNjguMTI5LDUzLjkzOCAgIGMtMC4yNzMtMC40NDctMC45OTQtMC43MTctMi4wNzYtMS4yNTRjLTEuMDg0LTAuNTM3LTYuNDEtMy4xMzgtNy40LTMuNDk1Yy0wLjk5My0wLjM1OC0xLjcxNy0wLjUzOC0yLjQzOCwwLjUzNyAgIGMtMC43MjEsMS4wNzYtMi43OTcsMy40OTUtMy40Myw0LjIxMmMtMC42MzIsMC43MTktMS4yNjMsMC44MDktMi4zNDcsMC4yNzFjLTEuMDgyLTAuNTM3LTQuNTcxLTEuNjczLTguNzA4LTUuMzMzICAgYy0zLjIxOS0yLjg0OC01LjM5My02LjM2NC02LjAyNS03LjQ0MWMtMC42MzEtMS4wNzUtMC4wNjYtMS42NTYsMC40NzUtMi4xOTFjMC40ODgtMC40ODIsMS4wODQtMS4yNTUsMS42MjUtMS44ODIgICBjMC41NDMtMC42MjgsMC43MjMtMS4wNzUsMS4wODItMS43OTNjMC4zNjMtMC43MTcsMC4xODItMS4zNDQtMC4wOS0xLjg4M2MtMC4yNy0wLjUzNy0yLjQzOC01LjgyNS0zLjM0LTcuOTc3ICAgYy0wLjkwMi0yLjE1LTEuODAzLTEuNzkyLTIuNDM2LTEuNzkyYy0wLjYzMSwwLTEuMzU0LTAuMDktMi4wNzYtMC4wOWMtMC43MjIsMC0xLjg5NiwwLjI2OS0yLjg4OSwxLjM0NCAgIGMtMC45OTIsMS4wNzYtMy43ODksMy42NzYtMy43ODksOC45NjNjMCw1LjI4OCwzLjg3OSwxMC4zOTcsNC40MjIsMTEuMTEzYzAuNTQxLDAuNzE2LDcuNDksMTEuOTIsMTguNSwxNi4yMjMgICBDNTguMiw2NS43NzEsNTguMiw2NC4zMzYsNjAuMTg2LDY0LjE1NmMxLjk4NC0wLjE3OSw2LjQwNi0yLjU5OSw3LjMxMi01LjEwN0M2OC4zOTgsNTYuNTM3LDY4LjM5OCw1NC4zODYsNjguMTI5LDUzLjkzOHoiIGZpbGw9IiNGRkZGRkYiLz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8Zz4KPC9nPgo8L3N2Zz4K" width="50" height="20" />
						    </div>
							</a>
        <?php } ?>
		</div>
	<?php }
}
// if ( $seomasternrj_social_icons_enabled == true ) {
//
// }
//	add_action('amp_post_template_head','seomasternrj_register_social_sharing_script');
function seomasternrj_register_social_sharing_script() {
			if( is_socialshare_or_socialsticky_enabled_in_seomasternrj() ) { ?>
				<script async custom-element="amp-social-share" src="https://cdn.ampproject.org/v0/amp-social-share-0.1.js"></script>
<?php }
}

//	25. Yoast meta Support
function seomasternrj_custom_yoast_meta(){
	global $redux_builder_amp;
	if ($redux_builder_amp['seomasternrj-seo-yoast-meta']) {
		if(! class_exists('YoastSEO_AMP') ) {
				if ( class_exists('WPSEO_Options')) {
					$options = WPSEO_Options::get_option( 'wpseo_social' );
					if ( $options['twitter'] === true ) {
						WPSEO_Twitter::get_instance();
					}
					if ( $options['opengraph'] === true ) {
						$GLOBALS['wpseo_og'] = new WPSEO_OpenGraph;
					}
					do_action( 'wpseo_opengraph' );
				}
		}//execute only if Glue is deactive
	echo strip_tags($redux_builder_amp['seomasternrj-seo-custom-additional-meta'], '<link><meta>' );
	} else {
		echo strip_tags($redux_builder_amp['seomasternrj-seo-custom-additional-meta'], '<link><meta>' );
	}
}

function seomasternrj_custom_yoast_meta_homepage(){
	global $redux_builder_amp;
	if ($redux_builder_amp['seomasternrj-seo-yoast-meta']) {
		if(! class_exists('YoastSEO_AMP') ) {
				if ( class_exists('WPSEO_Options')) {
					$options = WPSEO_Options::get_option( 'wpseo_social' );
					if ( $options['twitter'] === true ) {
						WPSEO_Twitter::get_instance();
					}
					if ( $options['opengraph'] === true ) {
						$GLOBALS['wpseo_og'] = new WPSEO_OpenGraph;
					}
				}
				do_action( 'wpseo_opengraph' );

		}//execute only if Glue is deactive
	echo strip_tags($redux_builder_amp['seomasternrj-seo-custom-additional-meta'], '<link><meta>' );
	}
}

function seomasternrj_add_proper_post_meta(){
	$check_custom_front_page = get_option('show_on_front');
	if ( $check_custom_front_page == 'page' ) {
		add_action( 'amp_post_template_head', 'seomasternrj_custom_yoast_meta_homepage' );

		add_filter('wpseo_opengraph_title', 'custom_twitter_title_homepage');
		add_filter('wpseo_twitter_title', 'custom_twitter_title_homepage');

		add_filter('wpseo_opengraph_desc', 'custom_twitter_description_homepage');
		add_filter('wpseo_twitter_description', 'custom_twitter_description_homepage');

		add_filter('wpseo_opengraph_url', 'custom_og_url_homepage');

		add_filter('wpseo_twitter_image', 'custom_og_image_homepage');
		add_filter('wpseo_opengraph_image', 'custom_og_image_homepage');
	} else {
		add_action( 'amp_post_template_head', 'seomasternrj_custom_yoast_meta' );
	}
}
add_action('pre_amp_render_post','seomasternrj_add_proper_post_meta');


function custom_twitter_title_homepage() {
	return  esc_attr( get_bloginfo( 'name' ) );
}
function custom_twitter_description_homepage() {
	return  esc_attr( get_bloginfo( 'description' ) );
}
function custom_og_url_homepage() {
	return esc_url( get_bloginfo( 'url' ) );
}
function custom_og_image_homepage() {
	if ( class_exists('WPSEO_Options') ) {
		$options = WPSEO_Options::get_option( 'wpseo_social' );
		return  $options['og_default_image'] ;
	}
}


//26. Extending Title Tagand De-Hooking the Standard one from AMP
add_action('amp_post_template_include_single','seomasternrj_remove_title_tags');
function seomasternrj_remove_title_tags(){
  remove_action('amp_post_template_head','amp_post_template_add_title');
  add_action('amp_post_template_head','seomasternrj_add_custom_title_tag');

  function seomasternrj_add_custom_title_tag(){
    global $redux_builder_amp; ?>
    <title> <?php

      // title for a single post and single page
      if( is_single() || is_page() ){
        global $post;
        $title = $post->post_title;
        $site_title =  $title . ' | ' . get_option( 'blogname' ) ;
      }

      // title for archive pages
      if ( is_archive() && $redux_builder_amp['seomasternrj-archive-support'] )  {
        $site_title = strip_tags(get_the_archive_title( '' )) . ' | ' . strip_tags(get_the_archive_description( '' ));
      }

      if ( is_home() ) {
        $site_title = get_bloginfo('name') . ' | ' . get_option( 'blogdescription' ) ;
        if  ( $redux_builder_amp['amp-frontpage-select-option']== 1) {
          $ID = $redux_builder_amp['amp-frontpage-select-option-pages'];
          $site_title =  get_the_title( $ID ) . ' | ' . get_option('blogname');
        } else {
          global $wp;
          $current_archive_url = home_url( $wp->request );
          $current_url_in_pieces = explode('/',$current_archive_url);
          $cnt = count($current_url_in_pieces);
          if( is_numeric( $current_url_in_pieces[  $cnt-1 ] ) ) {
            $site_title .= ' | Page '.$current_url_in_pieces[$cnt-1];
          }
        }
      }

      if( is_search() ) {
        $site_title =  $redux_builder_amp['amp-translator-search-text'] . '  ' . get_search_query();
      }

      if ( class_exists('WPSEO_Frontend') ) {
        $front = WPSEO_Frontend::get_instance();
        $title = $front->title( $site_title );

        // Code for Custom Frontpage Yoast SEO Title
        if ( class_exists('WPSEO_Meta') ) {

          // Yoast SEO Title
          $yaost_title = WPSEO_Options::get_option( 'wpseo' );
          if ( $yaost_title['website_name']) {
            $site_title  = $yaost_title['website_name'];
          } else {
            $site_title  =  get_bloginfo('name');
          }

          // Yoast SEO Title Seperator
          $wpseo_titles = WPSEO_Options::get_option( 'wpseo_titles' );
          $seperator_options = WPSEO_Option_Titles::get_instance()->get_separator_options();
          if ( $wpseo_titles['separator'] ) {
            $seperator = $seperator_options[ $wpseo_titles['separator'] ];
          } else {
            $seperator = ' - ';
          }

          $post_id = $redux_builder_amp['amp-frontpage-select-option-pages'];
          $custom_fp_title = WPSEO_Meta::get_value('title', $post_id );
          if ( is_home() && $redux_builder_amp['amp-frontpage-select-option'] ) {
            if ( $custom_fp_title ) {
              $title = $custom_fp_title;
            } else {
              $title = get_the_title($post_id) .' '. $seperator .' '. $site_title ;
            }
          }
        }

        echo $title;
      } else {
        echo $site_title;
      } ?>
    </title> <?php
  }
}

// 27. Clean the Defer issue
	// TODO : Get back to this issue. #407
		function seomasternrj_the_content_filter_full( $content_buffer ) {
            $seomasternrj_is_amp_endpoint = seomasternrj_is_amp_endpoint();
			if ( $seomasternrj_is_amp_endpoint ) {
				$content_buffer = preg_replace("/' defer='defer/", "", $content_buffer);
				$content_buffer = preg_replace("/' defer onload='/", "", $content_buffer);
				$content_buffer = preg_replace("/' defer /", "", $content_buffer);
				$content_buffer = preg_replace("/onclick=[^>]*/", "", $content_buffer);
                $content_buffer = preg_replace("/<\\/?thrive_headline(.|\\s)*?>/",'',$content_buffer);
                // Remove Extra styling added by other Themes/ Plugins
               	$content_buffer = preg_replace('/(<style(.*?)>(.*?)<\/style>)<!doctype html>/','<!doctype html>',$content_buffer);
               	$content_buffer = preg_replace('/(<style(.*?)>(.*?)<\/style>)(\/\*)/','$4',$content_buffer);
                $content_buffer = preg_replace("/<\\/?g(.|\\s)*?>/",'',$content_buffer);
                $content_buffer = preg_replace('/(<[^>]+) spellcheck="false"/', '$1', $content_buffer);
                $content_buffer = preg_replace('/(<[^>]+) spellcheck="true"/', '$1', $content_buffer);
//$content_buffer = preg_replace('/<style type=(.*?)>|\[.*?\]\s\{(.*)\}|<\/style>(?!(<\/noscript>)|(\n<\/head>)|(<noscript>))/','',$content_buffer);

            }
            return $content_buffer;
		}
	   ob_start('seomasternrj_the_content_filter_full');



// 28. Properly removes AMP if turned off from Post panel
add_filter( 'amp_skip_post', 'seomasternrj_skip_amp_post', 10, 3 );
function seomasternrj_skip_amp_post( $skip, $post_id, $post ) {
	$seomasternrj_amp_post_on_off_meta = get_post_meta( $post->ID , 'seomasternrj-amp-on-off' , true );
	if( $seomasternrj_amp_post_on_off_meta === 'hide-amp' ) {
		$skip = true;
	}
    return $skip;
}

// 29. Remove analytics code if Already added by Glue or Yoast SEO (#370)
	add_action('init','remove_analytics_code_if_available',20);
	function remove_analytics_code_if_available(){
		if ( class_exists('WPSEO_Options') && class_exists('YoastSEO_AMP') ) {
			$yoast_glue_seo = get_option('wpseo_amp');

			if ( $yoast_glue_seo['analytics-extra'] ) {
				remove_action('amp_post_template_head','seomasternrj_register_analytics_script', 20);
				remove_action('amp_post_template_footer','seomasternrj_analytics',11);
			}

			if ( class_exists('Yoast_GA_Options') ) {
				$UA = Yoast_GA_Options::instance()->get_tracking_code();
				if ( $UA ) {
					remove_action('amp_post_template_head','seomasternrj_register_analytics_script', 20);
					remove_action('amp_post_template_footer','seomasternrj_analytics',11);
				}
			}
		}
	}

//30. TagDiv menu issue removed
	add_action('init','seomasternrj_remove_tagdiv_mobile_menu');
	function seomasternrj_remove_tagdiv_mobile_menu() {
		if( class_exists( 'Mobile_Detect' )) {
			remove_action('option_stylesheet', array('td_mobile_theme', 'mobile'));
		}
	}

//31. removing scripts added by cleantalk
add_action('amp_init','seomasternrj_remove_js_script_cleantalk');
function seomasternrj_remove_js_script_cleantalk() {
    remove_action('wp_loaded', 'ct_add_nocache_script', 1);
}

//32. various lazy loading plugins Support
add_filter( 'amp_init', 'seomasternrj_lazy_loading_plugins_compatibility' );
function seomasternrj_lazy_loading_plugins_compatibility() {

    // Disable HTTP protocol removing on script, link, img, srcset and form tags.
    remove_filter( 'rocket_buffer', '__rocket_protocol_rewrite', PHP_INT_MAX );
    remove_filter( 'wp_calculate_image_srcset', '__rocket_protocol_rewrite_srcset', PHP_INT_MAX );
    // Disable Concatenate Google Fonts
//    add_filter( 'get_rocket_option_minify_google_fonts', '__return_false', PHP_INT_MAX );
    // Disable CSS & JS magnification
//    add_filter( 'get_rocket_option_minify_js', '__return_false', PHP_INT_MAX );
//    add_filter( 'get_rocket_option_minify_css', '__return_false', PHP_INT_MAX );

    //Lazy Load XT
		global $lazyloadxt;
		remove_filter( 'the_content', array( $lazyloadxt, 'filter_html' ) );
		remove_filter( 'widget_text', array( $lazyloadxt, 'filter_html' ) );
		remove_filter( 'post_thumbnail_html', array( $lazyloadxt, 'filter_html' ) );
		remove_filter( 'get_avatar', array( $lazyloadxt, 'filter_html' ) );

    // Lazy Load
		add_filter( 'lazyload_is_enabled', '__return_false', PHP_INT_MAX );
}
//
// This Caused issue, Please see: https://github.com/ahmedkaludi/accelerated-mobile-pages/issues/713
//
//add_action('amp_init','seomasternrj_cache_compatible_activator');
//function seomasternrj_cache_compatible_activator(){
//    add_action('template_redirect','seomasternrj_cache_plugin_compatible');
//}
//function seomasternrj_cache_plugin_compatible(){
//    $seomasternrj_is_amp_endpoint = seomasternrj_is_amp_endpoint();
//    if ( ! $seomasternrj_is_amp_endpoint ) {
//        return;
//    }
//    /**
//     * W3 total cache
//     */
//    add_filter( 'w3tc_minify_js_enable', array( $this, '_return_false' ) );
//    add_filter( 'w3tc_minify_css_enable', array( $this, '_return_false' ) );
//}

//Removing bj loading for amp
function seomasternrj_remove_bj_load() {
 	if ( function_exists( 'seomasternrj_is_amp_endpoint' ) && seomasternrj_is_amp_endpoint() ) {
 		add_filter( 'bjll/enabled', '__return_false' );
 	}
}
add_action( 'bjll/compat', 'seomasternrj_remove_bj_load' );

//33. Google tag manager support added
// Remove any old scripts that have been loaded by other Plugins
add_action('init', 'amp_gtm_remove_analytics_code');
function amp_gtm_remove_analytics_code() {
  global $redux_builder_amp;
  if( $redux_builder_amp['amp-use-gtm-option'] ) {
    remove_action('amp_post_template_footer','seomasternrj_analytics',11);
  	remove_action('amp_post_template_head','seomasternrj_register_analytics_script', 20);
  } else {
    remove_filter( 'amp_post_template_analytics', 'amp_gtm_add_gtm_support' );

  }
}

// Create GTM support
add_filter( 'amp_post_template_analytics', 'amp_gtm_add_gtm_support' );
function amp_gtm_add_gtm_support( $analytics ) {
	global $redux_builder_amp;
	if ( ! is_array( $analytics ) ) {
		$analytics = array();
	}

	$analytics['amp-gtm-googleanalytics'] = array(
		'type' => $redux_builder_amp['amp-gtm-analytics-type'],
		'attributes' => array(
			'data-credentials' 	=> 'include',
			'config'			=> 'https://www.googletagmanager.com/amp.json?id='. $redux_builder_amp['amp-gtm-id'] .'&gtm.url=SOURCE_URL'
		),
		'config_data' => array(
			'vars' => array(
				'account' =>  $redux_builder_amp['amp-gtm-analytics-code']
			),
			'triggers' => array(
				'trackPageview' => array(
					'on' => 'visible',
					'request' => 'pageview',
				),
			),
		),
	);

	return $analytics;
}

//34. social share boost compatibility Ticket #387
function social_sharing_removal_code() {
    remove_filter('the_content','ssb_in_content');
}
add_action('amp_init','social_sharing_removal_code', 9);



//37. compatibility with wp-html-compression
function seomasternrj_copat_wp_html_compression() {
	remove_action('template_redirect', 'wp_html_compression_start', -1);
	remove_action('get_header', 'wp_html_compression_start');
}
add_action('amp_init','seomasternrj_copat_wp_html_compression');

//38. Extra Design Specific Features
// add_action('pre_amp_render_post','seomasternrj_add_extra_functions',12);
// function seomasternrj_add_extra_functions() {
// 	global $redux_builder_amp;
// 	if ( $redux_builder_amp['amp-design-selector'] == 3 ) {
// 		require SEOMASTERNRJ_PLUGIN_DIR . '/templates/design-manager/design-3/functions.php';
// 	}
// }

//38. #529 editable archives
// add_filter( 'get_the_archive_title', 'seomasternrj_editable_archvies_title' );
// function seomasternrj_editable_archvies_title($title) {
// 	global $redux_builder_amp;
//     if ( is_category() ) {
//             $title = single_cat_title( $redux_builder_amp['amp-translator-archive-cat-text'].' ', false );
//         } elseif ( is_tag() ) {
//             $title = single_tag_title( $redux_builder_amp['amp-translator-archive-tag-text'].' ', false );
//         }
//     return $title;
// }

//39. #560 Header and Footer Editable html enabled script area
// add_action('amp_post_template_footer','seomasternrj_footer_html_output',11);
// function seomasternrj_footer_html_output() {
//   global $redux_builder_amp;
//   if( $redux_builder_amp['amp-footer-text-area-for-html'] ) {
//     echo $redux_builder_amp['amp-footer-text-area-for-html'] ;
//   }
// }

// add_action('amp_post_template_head','seomasternrj_header_html_output',11);
// function seomasternrj_header_html_output() {
//   global $redux_builder_amp;
//   if( $redux_builder_amp['amp-header-text-area-for-html'] ) {
//     echo $redux_builder_amp['amp-header-text-area-for-html'] ;
//   }
// }


//40. Meta Robots
// add_action('amp_post_template_head' , 'seomasternrj_talking_to_robots');
// function seomasternrj_talking_to_robots() {

//   global $redux_builder_amp;
//   global $wp;
//   $message_to_robots = '<meta name="robots" content="noindex,nofollow"/>';
//   $talk_to_robots=false;

//    //author arhives  index/noindex
//    if( is_author() && !$redux_builder_amp['seomasternrj-robots-archive-author-pages'] ) {
//   	$talk_to_robots = true;
//    }

//   //date ke archives index/noindex
//   if( is_date() && !$redux_builder_amp['seomasternrj-robots-archive-date-pages'] ) {
//     $talk_to_robots = true;
//   }

//   //Search pages noindexing by default
//   if( is_search() ) {
//     $talk_to_robots = true;
//   }

//   //categorys index/noindex
//   if( is_category()  && !$redux_builder_amp['seomasternrj-robots-archive-category-pages'] ) {
//     $talk_to_robots = true;
//   }

//   //categorys index/noindex
//   if( is_tag() && !$redux_builder_amp['seomasternrj-robots-archive-tag-pages'] ) {
//     $talk_to_robots = true;
//   }

//   if( is_archive() || is_home() ) {
//     if ( get_query_var( 'paged' ) ) {
//           $paged = get_query_var('paged');
//       } elseif ( get_query_var( 'page' ) ) {
//           $paged = get_query_var('page');
//       } else {
//           $paged = 1;
//       }
//       //sitewide archives sub pages index/noindex  ie page 2 onwards
//       if( $paged >= 2 && !$redux_builder_amp['seomasternrj-robots-archive-sub-pages-sitewide'] ) {
//       	$talk_to_robots = true;
//       }
//     }

// 	$page = $wp->query_vars['page'];
// 	if ( $redux_builder_amp['amp-frontpage-select-option'] && $page >= '2') {
// 		$talk_to_robots = true;
// 	}

//   if( $talk_to_robots ) {
//     	echo $message_to_robots;
//   }

// }

// 41. Rewrite URL only on save #511
function seomasternrj_auto_flush_on_save($redux_builder_amp) {
	if ( $redux_builder_amp['amp-on-off-for-all-pages'] == 1 || $redux_builder_amp['seomasternrj-archive-support'] == 1 ) {
		global $wp_rewrite;
		$wp_rewrite->flush_rules();
	}
}
add_action("redux/options/redux_builder_amp/saved",'seomasternrj_auto_flush_on_save', 10, 1);

// 42. registeing AMP sidebars
if (function_exists('register_sidebar')) {

	register_sidebar(array(
		'name' => 'AMP Above Loop',
		'id'   => 'seomasternrj-above-loop',
		'description'   => 'Widget area for above the Loop Output',
		'before_widget' => '<div class="category-widget-wrapper"><div class="category-widget-gutter">',
		'after_widget'  => '</div></div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>'
	));
	register_sidebar(array(
		'name' => 'AMP Below Loop',
		'id'   => 'seomasternrj-below-loop',
		'description'   => 'Widget area for below the Loop Output',
		'before_widget' => '<div class="category-widget-wrapper"><div class="category-widget-gutter">',
		'after_widget'  => '</div></div>',
		'before_title'  => '<h4>',
		'after_title'   => '</h4>'
	));

}

// 43. custom actions for widgets output
add_action( 'seomasternrj_home_above_loop' , 'seomasternrj_output_widget_content_above_loop' );
add_action( 'seomasternrj_frontpage_above_loop' , 'seomasternrj_output_widget_content_above_loop' );
function seomasternrj_output_widget_content_above_loop() {
    dynamic_sidebar( 'seomasternrj-above-loop' );
}

add_action( 'seomasternrj_home_below_loop' , 'seomasternrj_output_widget_content_below_loop' );
add_action( 'seomasternrj_frontpage_below_loop' , 'seomasternrj_output_widget_content_below_loop' );
function seomasternrj_output_widget_content_below_loop() {
    dynamic_sidebar( 'seomasternrj-below-loop' );
}



// 45. searchpage, frontpage, homepage structured data
add_filter( 'amp_post_template_metadata', 'seomasternrj_search_or_homepage_or_staticpage_metadata', 10, 2 );
function seomasternrj_search_or_homepage_or_staticpage_metadata( $metadata, $post ) {
		global $redux_builder_amp;

		if( is_search() || is_home() || ( is_front_page() && $redux_builder_amp['amp-frontpage-select-option'] )) {

			if( is_home() || is_front_page() ){
				global $wp;
				$current_url = home_url( $wp->request );
				$current_url = dirname( $current_url );
				$headline 	 =  get_bloginfo('name') . ' | ' . get_option( 'blogdescription' );
			} else {
				$current_url 	= trailingslashit(get_home_url())."?s=".get_search_query();
				$current_url 	= untrailingslashit( $current_url );
				$headline 		=  $redux_builder_amp['amp-translator-search-text'] . '  ' . get_search_query();
			}

			// placeholder Image area
			// if (! empty( $redux_builder_amp['amp-structured-data-placeholder-image']['url'] ) ) {
			// 	$structured_data_image_url = $redux_builder_amp['amp-structured-data-placeholder-image']['url'];
			// }
			// $structured_data_image =  $structured_data_image_url; //  Placeholder Image URL
			$structured_data_height = intval($redux_builder_amp['amp-structured-data-placeholder-image-height']); //  Placeholder Image width
			$structured_data_width = intval($redux_builder_amp['amp-structured-data-placeholder-image-width']); //  Placeholder Image height

			if( is_front_page() ) {
				$ID = $redux_builder_amp['amp-frontpage-select-option-pages']; // ID of slected front page
				$headline =  get_the_title( $ID ) . ' | ' . get_option('blogname');
				$static_page_data = get_post( $ID );

				$datePublished = $static_page_data->post_date;
				$dateModified = $static_page_data->post_modified;

				$featured_image_array = wp_get_attachment_image_src( get_post_thumbnail_id( $ID ) ); // Featured Image structured Data
				if( $featured_image_array ) {
					$structured_data_image = $featured_image_array[0];
					$structured_data_image = $featured_image_array[1];
					$structured_data_image = $featured_image_array[2];
				}
			} else {
			// To DO : check the entire else section .... time for search and homepage...wierd ???
				$datePublished = date( 'Y-m-d H:i:s', current_time( 'timestamp', 0 ) - 2 );
				// time difference is 2 minute between published and modified date
				$dateModified = date( 'Y-m-d H:i:s', current_time( 'timestamp', 0 ) );
			}
			$metadata['datePublished'] = $datePublished; // proper published date added
			$metadata['dateModified'] = $dateModified; // proper modified date

			// $metadata['image'] = array(
			// 	'@type' 	=> 'ImageObject',
			// 	'url' 		=> $structured_data_image ,
			// 	'height' 	=> $structured_data_height,
			// 	'width' 	=> $structured_data_width,
			// );

			$metadata['mainEntityOfPage'] = $current_url; // proper URL added
			$metadata['headline'] = $headline; // proper headline added
	}
	return $metadata;
}


// 46. search search search everywhere #615
require 'search-functions.php';



// 48. Remove all unwanted scripts on search pages
add_filter( 'amp_post_template_data', 'seomasternrj_remove_scripts_search_page' );
function seomasternrj_remove_scripts_search_page( $data ) {
	if( is_search() ) {
		// Remove all unwanted scripts on search pages
		unset( $data['amp_component_scripts']);
	}
	return $data;
}

// internal function for checing if social profiles have been set
if( !function_exists('seomasternrj_checking_any_social_profiles') ) {
	function seomasternrj_checking_any_social_profiles() {
		global $redux_builder_amp;
		if(
			$redux_builder_amp['enable-single-twittter-profile'] 	 ||
			$redux_builder_amp['enable-single-facebook-profile'] 	 ||
			$redux_builder_amp['enable-single-pintrest-profile'] 	 ||
			$redux_builder_amp['enable-single-google-plus-profile']	 ||
			$redux_builder_amp['enable-single-linkdin-profile'] 	 ||
			$redux_builder_amp['enable-single-youtube-profile'] 	 ||
			$redux_builder_amp['enable-single-instagram-profile'] 	 ||
			$redux_builder_amp['enable-single-VKontakte-profile'] 	 ||
			$redux_builder_amp['enable-single-reddit-profile'] 		 ||
			$redux_builder_amp['enable-single-snapchat-profile'] 	 ||
			$redux_builder_amp['enable-single-Tumblr-profile']
	 	) {
			return true;
		}
		return false;
	}
}

// 50. Properly adding noditification Scritps the AMP way



//51. Adding Digg Digg compatibility with AMP
function seomasternrj_dd_exclude_from_amp() {
if(seomasternrj_is_amp_endpoint()) {
    remove_filter('the_excerpt', 'dd_hook_wp_content');
    remove_filter('the_content', 'dd_hook_wp_content');
	}
}
add_action('template_redirect', 'seomasternrj_dd_exclude_from_amp');

//52. Adding a generalized sanitizer function for purifiying normal html to amp-html
function seomasternrj_content_sanitizer( $content ) {
	$amp_custom_post_content_input = $content;
	if ( !empty( $amp_custom_post_content_input ) ) {
		$amp_custom_content = new AMP_Content( $amp_custom_post_content_input,
				apply_filters( 'amp_content_embed_handlers', array(
						'AMP_Twitter_Embed_Handler' => array(),
						'AMP_YouTube_Embed_Handler' => array(),
						'AMP_Instagram_Embed_Handler' => array(),
						'AMP_Vine_Embed_Handler' => array(),
						'AMP_Facebook_Embed_Handler' => array(),
						'AMP_Gallery_Embed_Handler' => array(),
				) ),
				apply_filters(  'amp_content_sanitizers', array(
						 'AMP_Style_Sanitizer' => array(),
						 'AMP_Blacklist_Sanitizer' => array(),
						 'AMP_Img_Sanitizer' => array(),
						 'AMP_Video_Sanitizer' => array(),
						 'AMP_Audio_Sanitizer' => array(),
						 'AMP_Iframe_Sanitizer' => array(
							 'add_placeholder' => true,
						 ),
				)  )
		);

		if ( $amp_custom_content ) {
			global $data;
			$data['amp_component_scripts'] 	= $amp_custom_content->get_amp_scripts();
			$data['post_amp_styles'] 		= $amp_custom_content->get_amp_styles();
			return $amp_custom_content->get_amp_content();
		}
		return '';
	}
}


//53. Adding the Markup for AMP Woocommerce latest Products
/*******************************
Examples:

[amp-woocommerce num=5]
[amp-woocommerce num=5 link=noamp]
*******************************/
	 function get_amp_latest_prodcuts_markup( $atts ) {
		 // initializing these to avoid debug errors
		 global $redux_builder_amp;
		 global $woocommerce;

		 if( !class_exists( 'WooCommerce' ) ){
			 return;
		 }

		 $atts[] = shortcode_atts( array(
				 'num' => get_permalink($atts['num']),
				 'link' => get_permalink($atts['link'])
		 ), $atts );

		 $exclude_ids = get_option('seomasternrj_exclude_post');
		 $number_of_latest_prcts = $atts['num'] ;

			$q = new WP_Query( array(
			 'post_type'           => 'product',
			 'orderby'             => 'date',
			 'paged'               => esc_attr($paged),
			 'post__not_in' 		  => $exclude_ids,
			 'has_password' => false,
			 'post_status'=> 'publish',
			 'posts_per_page' => $number_of_latest_prcts
			) );

		  if ( $q->have_posts() ) :  $content .= '<ul class="seomasternrj_wc_shortcode">';
            while ( $q->have_posts() ) : $q->the_post();
						global $post;
						global $product;
						if( $atts['link'] === 'amp' ) {
							$seomasternrj_post_url = trailingslashit( get_permalink() ) . SEOMASTERNRJ_AMP_QUERY_VAR ;
						} else {
							$seomasternrj_post_url = trailingslashit( get_permalink() ) ;
						}
						$content .= '<li class="seomasternrj_wc_shortcode_child"><a href="'.$seomasternrj_post_url.'">';

//						$content .= '<div class="amp-wp-content seomasternrj-wc-parent"><div class="amp-wp-content featured-image-content">';
						if ( has_post_thumbnail() ) {
							$thumb_id = get_post_thumbnail_id();
							$thumb_url_array = wp_get_attachment_image_src($thumb_id, 'thumbnail', true);
							$thumb_url = $thumb_url_array[0];

							$content .= '<amp-img src='.$thumb_url.' width="150" height="150" layout="responsive"></amp-img>' ;
						}
							if ( $product->is_on_sale() ) {
								$content .=  '<span class="onsale">' . 'Sale!' . '</span>';
							}
//						$content .= '</div>';
							$content .= '<div class="seomasternrj-wc-title">'.get_the_title().'</div>';
							if (  class_exists( 'WooCommerce' )  ) {
	//							$content .= '<div class="seomasternrj-wc-price">';
								$amp_product_price 	=  $woocommerce->product_factory->get_product()->get_price_html();
								$context = '';
								$allowed_tags 		= wp_kses_allowed_html( $context );

							$stock_status = $product->is_in_stock() ? 'InStock' : 'OutOfStock' ;
							if ( $amp_product_price && $stock_status = 'InStock' ) {
								$content .= '<div class="seomasternrj-wc-price">' .  wp_kses( $amp_product_price ,  $allowed_tags  ) . '</div>' ;
							}

							$rating_count = $product->get_rating_count();
							$rating = $product->get_average_rating();
							if (  get_option( 'woocommerce_enable_review_rating' ) === 'yes' && $rating_count ) {
								$content .= '<div class="seomasternrj_wc_star_rating" class="star-rating" title="Rated '.$rating.' out of 5' . '">';
								$content .= '<span class="seomasternrj_wc_star_rating_text" ><strong>'.$rating.'</strong>'.' out of 5 </span>';
								$content .= '</div>';
							}

							}
                        $content .= '</a></li>';  ?>
					<?php endwhile;  $content .= '</ul>'; ?>
			<?php endif; ?>
			<?php wp_reset_postdata();

			 // Add AMP Woocommerce latest Products only on AMP Endpoint
			 $endpoint_check = is_amp_endpoint();
			 if ( $endpoint_check ) {
				 return $content;
			 }
	 }

	 // Generating Short code for AMP Woocommerce latest Products
	 function seomasternrj_latest_products_register_shortcodes() {
		 add_shortcode('amp-woocommerce', 'get_amp_latest_prodcuts_markup');
	 }
	 add_action( 'amp_init', 'seomasternrj_latest_products_register_shortcodes');

	 // Adding the styling for AMP Woocommerce latest Products
   add_action('amp_post_template_css','amp_latest_products_styling',PHP_INT_MAX);
   function amp_latest_products_styling() { ?>
		.seomasternrj_wc_shortcode{padding:0}
		.seomasternrj_wc_shortcode li{ font-size:12px; line-height: 1; float: left;max-width: 150px;list-style-type: none;margin: 10px;}
		.single-post .seomasternrj_wc_shortcode li amp-img{margin:0}
		.seomasternrj-wc-title{ margin: 10px 0px; }
		.seomasternrj-wc-price{ color:#444 } <?php
   }

// 54. Change the default values of post meta for AMP pages. #746
add_action('admin_head','seomasternrj_change_default_amp_page_meta');
function seomasternrj_change_default_amp_page_meta() {
	global $redux_builder_amp;
	$check_meta 		= get_option('seomasternrj_default_pages_to');
	$checker			= 'show';
	$control			= $redux_builder_amp['amp-pages-meta-default'];
	$meta_value_to_upate = 'default';

	if ( $control  === 'hide' ) {
		$checker				= 'hide';
		$meta_value_to_upate 	= 'hide-amp';
	}

	// Check and Run only if the value has been changed, else return
	if ( $check_meta === $checker ) {
		return;
	}
	// Get all the pages and update the post meta
	$pages = get_pages(array());
	foreach($pages as $page){
	    update_post_meta($page->ID,'seomasternrj-amp-on-off', $meta_value_to_upate);
	}
	// Update the option as the process has been done and update an option
	update_option('seomasternrj_default_pages_to', $checker);
	return ;
}


// Adding the meta="description" from yoast or from the content
add_action('amp_post_template_head','seomasternrj_meta_description');
function seomasternrj_meta_description() {
 global $redux_builder_amp;
 if( !$redux_builder_amp['seomasternrj-seo-meta-description'] ){
	 return;
 }
 
 global $post;
 $desc = "" ;

 if($redux_builder_amp['seomasternrj-seo-yoast-description']){
		if ( class_exists('WPSEO_Frontend') ) {
			// general Description of everywhere
			$front = WPSEO_Frontend::get_instance();
			$desc = addslashes( strip_tags( $front->metadesc( false ) ) );

			// Static front page
			// Code for Custom Frontpage Yoast SEO Description
			$post_id = $redux_builder_amp['amp-frontpage-select-option-pages'];
			if ( class_exists('WPSEO_Meta') ) {
				if ( is_home() && $redux_builder_amp['amp-frontpage-select-option'] ) {
					$desc = addslashes( strip_tags( WPSEO_Meta::get_value('metadesc', $post_id ) ) );
				}
			}
		}
		// for search
		if( is_search() ) {
			$desc = addslashes( $redux_builder_amp['amp-translator-search-text'] . '  ' . get_search_query() );
		}
	} else {
		if( is_home() ) {
			// normal home page
			$desc= addslashes( strip_tags( get_bloginfo( 'description' ) ) );
		}

		if( is_archive() ) {
			$desc= addslashes( strip_tags( get_the_archive_description() ) );
		}

		if( is_single() || is_page() ) {
				if( has_excerpt() ){
					$desc = get_the_excerpt();
				} else {
					global $post;
					$id = $post->ID;
					$desc = get_post($id)->post_content;
				}
				$desc = addslashes( wp_trim_words( strip_tags( $desc ) , '15'  ) );
		}

		if( is_search() ) {
			$desc = addslashes( $redux_builder_amp['amp-translator-search-text'] . ' ' . get_search_query() );
		}

		if( is_home() && $redux_builder_amp['amp-frontpage-select-option'] ) {
			$post_id = $redux_builder_amp['amp-frontpage-select-option-pages'] ;
			$desc = addslashes( wp_trim_words(  strip_tags( get_post_field('post_content', $post_id) ) , '15' ) );
		}
	}

	// strip_shortcodes  strategy not working here so had to do this way
	// strips shortcodes
	$desc= preg_replace('/\[(.*)?\]/','',$desc);

	if( $desc ) {
		echo '<meta name="description" content="'. $desc .'"/>';
	}
}
// Call Feature
add_action('seomasternrj_call_button','seomasternrj_call_button_html_output');
function seomasternrj_call_button_html_output(){
global $redux_builder_amp;
if ($redux_builder_amp['seomasternrj-callnow-button']) {
?>
<div class="callnow"><a href="tel:<?php echo $redux_builder_amp['enable-amp-call-numberfield']; ?>"></a></div>
<?php }
 }