<?php global $redux_builder_amp;
  wp_reset_postdata();

  $seomasternrj_backto_nonamp = " ";
  if ( is_home() ) {
    $seomasternrj_backto_nonamp = untrailingslashit(home_url()).'?nonamp=1';
  }
  if ( is_single() ){
    global $post;
    $seomasternrj_backto_nonamp = untrailingslashit(get_permalink( $post->ID )).'?nonamp=1';
  }
  if ( is_page() ){
    global $post;
    $seomasternrj_backto_nonamp = untrailingslashit(get_permalink( $post->ID )).'?nonamp=1';
  }
  if( is_archive() ) {
    global $wp;
    $seomasternrj_backto_nonamp = esc_url( untrailingslashit(home_url( $wp->request )).'?nonamp=1' );
    $seomasternrj_backto_nonamp = preg_replace('/\/amp\?nonamp=1/','?nonamp=1',$seomasternrj_backto_nonamp);
  }
  ?>
  <?php if( $redux_builder_amp['interlink_switch'] == 1 ):?>
  <div class="footer-interlink-area">
    <div class="service-interlinking">
    <h3>Our Services</h3>
        <ul>
            <?php if ( $redux_builder_amp['interlinks'] ):
                foreach ( $redux_builder_amp['interlinks'] as $interlinks => $interlinks_value ) {
                $interlinks_value = explode(",", $interlinks_value);
            ?>
                <li><a target="_blank" href="<?php echo $interlinks_value[1];?>"><?php echo $interlinks_value[0];?></a></li>
            <?php } endif; ?>
        </ul>
    </div>
  </div>
  <?php endif;?>
  
 <?php if( $redux_builder_amp['map_switch'] == 1 ):?>
		<div class="footer-map-area">
		<div class="footer-map">
			<a target="_blank" href="<?php echo $redux_builder_amp['footer_map_url'];?>">
				<amp-img  src="<?php echo $redux_builder_amp['footer_map_img']['url'];?>" alt="Google Map" height="500" width="1000" layout="responsive"></amp-img>
			</a>
		</div>
	</div>
<?php endif;?>
<?php if($redux_builder_amp['footer-extra-code']):?>
    <div class="footer-extra amp-wp-content">
        <?php echo $redux_builder_amp['footer-extra-code'];?>
    </div>
<?php endif;?>
<div class="footer-info-area">
  <div class="container">
    <div class="row">
      <div class="col-md-12 col-lg-12 col-sm-12 col-xs-12">
          <h2>Contact Us</h2>
          <p><?php echo $redux_builder_amp['amp-address']?></p>
          <a href="tel:<?php echo $redux_builder_amp['amp-phone']?>"><?php echo $redux_builder_amp['amp-phone']?></a>
          <a href="mailto:<?php echo $redux_builder_amp['amp-email']?>"><?php echo $redux_builder_amp['amp-email']?></a>
           <?php if($redux_builder_amp['social-links'] == 1):?>
  				<div class="social-media-links">
					<?php
					if ( $redux_builder_amp['single-social-link'] ):
						foreach ( $redux_builder_amp['single-social-link'] as $single_social_link => $single_social_value ) {
							$single_social_value = explode(",", $single_social_value);
					?>
						<a target="_blank" class="amp-social-share-<?php echo $single_social_value[0];?>" href="<?php echo $single_social_value[1];?>"></a>
					<?php
						}
					endif;        
					?>
					<?php if( $redux_builder_amp['google_review'] ):?>
						<div class="google-review-btn">
							<a target="_blank" href="<?php echo $redux_builder_amp['google_review'];?>">Review us on Google plus</a>
						</div>
					<?php endif;?>
  				</div>
			<?php endif;?>
      </div>
    </div>
  </div>
</div>
  <footer class="container">
      <div id="footer">
         <div class="amp-wp-content copyright-area">
            <?php
              global $allowed_html;
              echo wp_kses($redux_builder_amp['amp-translator-footer-text'],$allowed_html) ;
              ?>
          </div>
      </div>
  </footer>
<?php do_action('seomasternrj_global_after_footer'); ?>
