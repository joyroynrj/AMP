<?php global $redux_builder_amp , $wp;
$post_id = $redux_builder_amp['amp-frontpage-select-option-pages'];
$template = new AMP_Post_Template( $post_id );?>
<!doctype html>
<html amp <?php echo AMP_HTML_Utils::build_attributes_string( $this->get( 'html_tag_attributes' ) ); ?>>
<head>
	<meta charset="utf-8"> <?php
	$page = $wp->query_vars['page'];
	if ( $page >= '2') { ?>
		<link rel="canonical" href="<?php
		$ID = $redux_builder_amp['amp-frontpage-select-option-pages'];
		echo trailingslashit( get_permalink( $ID ) ) . '?page=' . $page ?>"> <?php
	} else { ?>
		<link rel="canonical" href="<?php
		$ID = $redux_builder_amp['amp-frontpage-select-option-pages'];
		echo get_permalink( $ID ) ?>"> <?php
	} ?>
	<meta name="viewport" content="width=device-width,initial-scale=1,minimum-scale=1,maximum-scale=1,user-scalable=no">
	<?php do_action( 'amp_post_template_head', $this ); ?>
	<?php
		$amp_custom_content_enable = get_post_meta($template->data['post_id'], 'seomasternrj_custom_content_editor_checkbox', true);
		if ( ! $amp_custom_content_enable ) {
			$amp_component_scripts = $template->data['amp_component_scripts'];
			foreach ($amp_component_scripts as $seomasternrj_service => $seomasternrj_js_file) { ?>
				<script custom-element="<?php echo $seomasternrj_service; ?>"  src="<?php echo $seomasternrj_js_file; ?>" async></script> <?php
			}
		}	 ?>
		<script async custom-element="amp-social-share" src="https://cdn.ampproject.org/v0/amp-social-share-0.1.js"></script>
	<style amp-custom>
	<?php $this->load_parts( array( 'style' ) ); ?>
	<?php do_action( 'amp_post_template_css', $this ); ?>
	</style>
	<?php if($redux_builder_amp['slider_switch'] == 1):?>
	<script async custom-element="amp-carousel" src="https://cdn.ampproject.org/v0/amp-carousel-0.1.js"></script>
	<?php endif;?>
</head>
<body class="single-post design_2_wrapper">
<?php $this->load_parts( array( 'header-bar' ) ); ?>

	<?php global  $redux_builder_amp; if( $redux_builder_amp['seomasternrj-title-on-front-page'] ) { ?>
		<header class="amp-wp-article-header seomasternrj-title">
			<h1 class="amp-wp-title">
				<?php $ID = $redux_builder_amp['amp-frontpage-select-option-pages'];
							echo get_the_title( $ID ) ; ?>
			</h1>
		</header>
<?php } ?>

<?php do_action( 'seomasternrj_after_header', $this ); ?>
<?php do_action('seomasternrj_frontpage_above_loop') ?>
<?php $home_slider = $redux_builder_amp['home_slider']; ?>
<?php if($redux_builder_amp['slider_switch'] == 1):?>
<div class="banner-carrousel">
<amp-carousel id="hero-images" width="1000" height="<?php if($redux_builder_amp['home_slider']['url']):?><?php echo $redux_builder_amp['home_slider']['url'];?><?php else:?>360<?php endif;?>" type="slides" layout="responsive" autoplay delay="5000">
<?php foreach($home_slider as $home_sliders): ?>
<figure>
    <amp-img  src="<?php echo $home_sliders['image'];?>"  layout="fill" attribution="visualhunt"></amp-img>
     <figcaption><?php echo $home_sliders['title'];?></figcaption>
</figure>
<?php endforeach;?>
</amp-carousel>
</div>
<?php endif;?>

<main>
	<div class="amp-wp-content the_content"> <?php

		// Normal Front Page Content
		if ( ! $amp_custom_content_enable ) {
			echo $template->data['post_amp_content'];
		} else {
			// Custom/Alternative AMP content added through post meta
			echo $template->data['seomasternrj_amp_content'];
		}

		do_action( 'seomasternrj_after_post_content', $this ); ?>

	</div>

	<?php $data = get_option( 'seomasternrj_design' );
		$enable_comments = false;

		if ($data['elements'] == '') {
		 	$data['elements'] = "meta_info:1,title:1,featured_image:1,content:1,meta_taxonomy:1,social_icons:1,comments:1,related_posts:1";
		}
		if( isset( $data['elements'] ) || ! empty( $data['elements'] ) ){
			$options = explode( ',', $data['elements'] );
		};
		if ($options): foreach ($options as $key=>$value) {
			switch ($value) {
					case 'comments:1':
						$enable_comments = true;
					break;
			}
		} endif;
	 ?>


<!------  post loop ------>
	<?php do_action('seomasternrj_post_before_loop') ?>

	<?php
		if ( get_query_var( 'paged' ) ) {
	        $paged = get_query_var('paged');
	    } elseif ( get_query_var( 'page' ) ) {
	        $paged = get_query_var('page');
	    } else {
	        $paged = 1;
	    }

	    $exclude_ids = get_option('seomasternrj_exclude_post');

		$args = array(
			'post_type'           => 'post',
			'orderby'             => 'date',
			'paged'               => esc_attr($paged),
			'post__not_in' 		  => $exclude_ids,
			'has_password' => false ,
			'post_status'=> 'publish'
		);
		$filtered_args = apply_filters('seomasternrj_query_args', $args);
		$q = new WP_Query( $filtered_args ); ?>

 	<?php if ( is_archive() ) {
 			the_archive_title( '<h3 class="page-title">', '</h3>' );
 			the_archive_description( '<div class="taxonomy-description">', '</div>' );
 		} ?>

	<?php if ( $q->have_posts() ) : while ( $q->have_posts() ) : $q->the_post();
		$seomasternrj_amp_post_url = trailingslashit( trailingslashit( get_permalink() ) . SEOMASTERNRJ_AMP_QUERY_VAR ) ; ?>

		<div class="amp-wp-content amp-loop-list">
			<?php if ( has_post_thumbnail() ) { ?>
				<?php
				$thumb_id = get_post_thumbnail_id();
				$thumb_url_array = wp_get_attachment_image_src($thumb_id, 'thumbnail', true);
				$thumb_url = $thumb_url_array[0];
				?>
				<div class="home-post_image">
					<a href="<?php echo esc_url( $seomasternrj_amp_post_url ); ?>">
						<amp-img src=<?php echo $thumb_url ?>
							<?php if( $redux_builder_amp['seomasternrj-homepage-posts-image-modify-size'] ) { ?>
							 width=<?php global $redux_builder_amp; echo $redux_builder_amp['seomasternrj-homepage-posts-design-1-2-width'] ?>
							 height=<?php global $redux_builder_amp; echo $redux_builder_amp['seomasternrj-homepage-posts-design-1-2-height'] ?>
						 <?php } else { ?>
							 width=100
							 height=75
						 <?php } ?>
						></amp-img>
					</a>
			</div>
			<?php } ?>

			<div class="amp-wp-post-content">

				<h2 class="amp-wp-title"> <a href="<?php echo esc_url( $seomasternrj_amp_post_url ); ?>"> <?php the_title(); ?></a></h2>

				<?php
					if(has_excerpt()){
						$content = get_the_excerpt();
					}else{
						$content = get_the_content();
					}
				?>
		        <p><?php echo wp_trim_words( strip_shortcodes( $content ) , '15'  ); ?></p>

		    </div>
            <div class="cb"></div>
	</div>

	<?php endwhile;  ?>
	<?php endif; ?>
	<?php wp_reset_postdata(); ?>

	<?php do_action('seomasternrj_post_after_loop') ?>

<!---- post loop end---->


	<div class="amp-wp-content post-pagination-meta">
		<?php $this->load_parts( apply_filters( 'amp_post_template_meta_parts', array( 'meta-taxonomy' ) ) ); ?>
	</div>
</main>
<amp-social-share type="gplus"   width="0" height="0"></amp-social-share>
	<?php do_action('seomasternrj_frontpage_below_loop') ?>

	<?php $this->load_parts( array( 'footer' ) ); ?>
	<?php do_action( 'amp_post_template_footer', $this ); ?>
	
	

</body>
</html>
