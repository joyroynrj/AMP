<div class="amp-wp-article-header amp-wp-article-category seomasternrj-meta-taxonomy ">
<?php	global $redux_builder_amp;
			$seomasternrj_tags=  get_the_terms( $this->ID, 'post_tag' );
			if ( $seomasternrj_tags && ! is_wp_error( $seomasternrj_tags ) ) :?>
		<div class="amp-wp-meta amp-wp-tax-tag seomasternrj-tax-tag">
				<?php
				//if RTL is OFF
				if(!$redux_builder_amp['amp-rtl-select-option']) {
						 global $redux_builder_amp; printf( __($redux_builder_amp['amp-translator-tags-text'] .' ', 'amp' ));
							}

				foreach ($seomasternrj_tags as $tag) {
            if($redux_builder_amp['seomasternrj-archive-support']){
							   echo ('<span><a href="'.trailingslashit( trailingslashit( get_tag_link( $tag->term_taxonomy_id ) ) . 'amp' ) . '" >'.$tag->name .'</a></span>');
          } else {
                      echo ('<span>'.$tag->name .'</span>');
          }
				}

				//if RTL is ON
				if($redux_builder_amp['amp-rtl-select-option']) {
						 global $redux_builder_amp; printf( __($redux_builder_amp['amp-translator-tags-text'] .' ', 'amp' ));
							}
				?>

		</div>
<?php endif;?>
</div>
