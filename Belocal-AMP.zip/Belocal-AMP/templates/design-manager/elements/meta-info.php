<div class="amp-wp-article-header seomasternrj-meta-info">
	<div class="amp-wp-content post-title-meta">

			<ul class="amp-wp-meta amp-meta-wrapper">
<?php $post_author = $this->get( 'post_author' ); ?>
<?php if ( $post_author ) : ?>
	<?php $author_avatar_url = get_avatar_url( $post_author->user_email, array( 'size' => 24 ) ); ?>
	<div class="amp-wp-meta amp-wp-byline">
		<?php if ( function_exists( 'get_avatar_url' ) ) : ?>
			<amp-img src="<?php echo esc_url( $author_avatar_url ); ?>" width="24" height="24" layout="fixed"></amp-img>
		<?php endif; ?>
		<span class="amp-wp-author author vcard"><?php echo esc_html( $post_author->display_name ); ?></span>

		<li class="amp-wp-meta-date"> <?php global $redux_builder_amp;  _e($redux_builder_amp['amp-translator-on-text']." ",'seomasternrj'); the_time( get_option( 'date_format' ) ) ?></li>

	</div>
<?php endif; ?>

<?php
  $seomasternrj_categories = get_the_terms( $this->ID, 'category' );
  if ( $seomasternrj_categories ) : ?>
  	<div class="amp-wp-meta amp-wp-tax-category seomasternrj-tax-category">

      <?php foreach ($seomasternrj_categories as $cat ) {
					if($redux_builder_amp['seomasternrj-archive-support']){
            	echo ('<span><a href="'. trailingslashit( trailingslashit( get_category_link( $cat->term_taxonomy_id ) ) .'amp' ) . '" >'.$cat->name .'</a></span>');
				} else {
	echo ('<span>'.$cat->name .'</span>');
				}
      }

			//if RTL is ON

			 ?>
  	</div>
  <?php endif; ?>

			</ul>
	</div>
</div>
