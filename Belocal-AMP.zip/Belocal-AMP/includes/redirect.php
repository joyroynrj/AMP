<?php
// Redirection for Homepage and Archive Pages when Turned Off from options panel
function seomasternrj_check_amp_page_status() {
  global $redux_builder_amp;

  if ( seomasternrj_is_amp_endpoint() ) {
    if ( is_archive() && $redux_builder_amp['seomasternrj-archive-support'] == 0 ) {
      global $wp;
      $redirection_location  =  add_query_arg( '', '', home_url( $wp->request ) );
      $redirection_location  =  trailingslashit($redirection_location );
      $redirection_location  =  dirname($redirection_location);
      wp_safe_redirect( $redirection_location );
      exit;
    }
  }
}
add_action( 'template_redirect', 'seomasternrj_check_amp_page_status', 10 );


function seomasternrj_page_template_redirect() {
  global $redux_builder_amp;

  if($redux_builder_amp['amp-mobile-redirection']){

    session_start();
    if( $_SESSION['seomasternrj_amp_mode']=='mobile-on' && $_SESSION['seomasternrj_mobile']=='exit'){
      return;
    }
    if( wp_is_mobile() && $_SESSION['seomasternrj_amp_mode']=='mobile-on' && $_GET['nonamp']==1){
      // non mobile session variable creation
      session_start();
      $_SESSION['seomasternrj_mobile']='exit';
      if ( seomasternrj_is_amp_endpoint() ) {
        session_destroy();
      }
    }

	  if ( wp_is_mobile() ) {
			if ( seomasternrj_is_amp_endpoint() ) {
				return;
			} else {
        if(is_page() && $redux_builder_amp['amp-on-off-for-all-pages'] == 0){return;}
        if( !isset($_SESSION['seomasternrj_amp_mode']) || !isset($_GET['nonamp']) ) {
          $_SESSION['seomasternrj_amp_mode']='mobile-on';
          if ( is_home() ) {
            if ( $redux_builder_amp['seomasternrj-homepage-on-off-support'] == 1 ) {
              wp_redirect( trailingslashit( esc_url( home_url() ) ) . SEOMASTERNRJ_AMP_QUERY_VAR ,  301 );
              exit();
            }
  				}
          elseif ( is_archive() ) {
            if ( $redux_builder_amp['seomasternrj-archive-support'] == 1 ) {
              global $wp;
              $current_archive_url = home_url( $wp->request );
              wp_redirect( trailingslashit( esc_url( $current_archive_url ) ) . SEOMASTERNRJ_AMP_QUERY_VAR , 301 );
              exit();
            }
  				} else {
            $seomasternrj_amp_post_on_off_meta = get_post_meta( get_the_ID(),'seomasternrj-amp-on-off',true);
            if( $seomasternrj_amp_post_on_off_meta === 'hide-amp' ) {
              //dont Echo anything
            } else {
  					wp_redirect( trailingslashit( esc_url( ( get_permalink( $id ) ) ) ) . SEOMASTERNRJ_AMP_QUERY_VAR , 301 );
  					exit();
            }
  				}
			  }
      }
		}

	}
}
add_action( 'template_redirect', 'seomasternrj_page_template_redirect', 30 );


add_action( 'template_redirect', 'seomasternrj_page_template_redirect_archive', 10 );
function seomasternrj_page_template_redirect_archive() {

	if ( is_404() ) {
		if( seomasternrj_is_amp_endpoint() ) {
			global $wp;
			$seomasternrj_404_url 	= add_query_arg( '', '', home_url( $wp->request ) );
			$seomasternrj_404_url	= trailingslashit($seomasternrj_404_url );
			$seomasternrj_404_url = dirname($seomasternrj_404_url);
			wp_redirect( esc_url( $seomasternrj_404_url )  , 301 );
			exit();
		}
	}
}
