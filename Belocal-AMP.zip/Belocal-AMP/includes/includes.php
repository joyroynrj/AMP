<?php
/* This file will contain all the extra code that works like a supporting.
1. Register AMP menu

*/
// 1. AMP menu code
	// Registering Custom AMP menu for this plugin
	// 1.1 AMP Header menu
	if (! function_exists( 'seomasternrj_menu') ) {
		function seomasternrj_menu() {
		  register_nav_menus(
		    array(
		      'amp-menu' => __( 'AMP Menu','seomasternrj' ),
		    )
		  );
		}
		add_action( 'init', 'seomasternrj_menu' );
	}

?>