<?php
// Admin Panel Options

if ( ! class_exists( 'Redux' ) ) {
    return;
}

// Option name where all the Redux data is stored.
$opt_name = "redux_builder_amp";

// All the possible arguments for Redux.
//$amp_redux_header = '<span id="name"><span style="color: #4dbefa;">U</span>ltimate <span style="color: #4dbefa;">W</span>idgets</span>';

$args = array(
    // TYPICAL -> Change these values as you need/desire
    'opt_name'              => 'redux_builder_amp', // This is where your data is stored in the database and also becomes your global variable name.
    'display_name'          =>  __( 'Belocal SEO Master','seomasternrj' ), // Name that appears at the top of your panel
    'menu_type'             => 'menu', //Specify if the admin menu should appear or not. Options: menu or submenu (Under appearance only)
    'allow_sub_menu'        => true, // Show the sections below the admin menu item or not
    'menu_title'            => __( 'Belocal SEO Master', 'seomasternrj' ),
    'page_title'            => 'Belocal SEO Master',
    'display_version'       => 'Developed By Joy Roy',
    'update_notice'         => false,
    'intro_text'            => 'Welcome to Belocal SEO Master Option Panel',
    'global_variable'       => '', // Set a different name for your global variable other than the opt_name
    'dev_mode'              => false, // Show the time the page took to load, etc
    'customizer'            => false, // Enable basic customizer support,
    'async_typography'      => false, // Enable async for fonts,
    'disable_save_warn'     => true,
    'open_expanded'         => false,
    // OPTIONAL -> Give you extra features
    'page_priority'         => null, // Order where the menu appears in the admin area. If there is any conflict, something will not show. Warning.
    'page_parent'           => 'themes.php', // For a full list of options, visit: http://codex.wordpress.org/Function_Reference/add_submenu_page#Parameters
    'page_permissions'      => 'manage_options', // Permissions needed to access the options panel.
    'last_tab'              => '', // Force your panel to always open to a specific tab (by id)
    'page_icon'             => 'dashicons-cloud', // Icon displayed in the admin panel next to your menu_title
    'page_slug'             => 'amp_options', // Page slug used to denote the panel
    'save_defaults'         => true, // On load save the defaults to DB before user clicks save or not
    'default_show'          => false, // If true, shows the default value next to each field that is not the default value.
    'default_mark'          => '', // What to print by the field's title if the value shown is default. Suggested: *
    'admin_bar'             => false,
    'admin_bar_icon'        => 'dashicons-cloud',
    // CAREFUL -> These options are for advanced use only
    'output'                => false, // Global shut-off for dynamic CSS output by the framework. Will also disable google fonts output
    'output_tag'            => false, // Allows dynamic CSS to be generated for customizer and google fonts, but stops the dynamic CSS from going to the head
    //'domain'              => 'redux-framework', // Translation domain key. Don't change this unless you want to retranslate all of Redux.
    'footer_credit'         => false, // Disable the footer credit of Redux. Please leave if you can help it.
    'footer_text'           => "",
    'show_import_export'    => false,
    'system_info'           => false,

);



Redux::setArgs( "redux_builder_amp", $args );




    $tabs = array(
        array(
            'id'      => 'redux-help-tab-1',
            'title'   => __( 'Theme Information 1', 'admin_folder' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'admin_folder' )
        ),
        array(
            'id'      => 'redux-help-tab-2',
            'title'   => __( 'Theme Information 2', 'admin_folder' ),
            'content' => __( '<p>This is the tab content, HTML is allowed.</p>', 'admin_folder' )
        )
    );
    Redux::setHelpTab( $opt_name, $tabs );

    // Set the help sidebar
    $content = __( '<p>This is the sidebar content, HTML is allowed.</p>', 'admin_folder' );
    Redux::setHelpSidebar( $opt_name, $content );


    /*
     * <--- END HELP TABS
     */

    function seomasternrj_plugin_activation_notice() {
      $output ='';
      include_once( ABSPATH . 'wp-admin/includes/plugin.php' );
      if ( is_plugin_inactive( 'amp/amp.php' ) ) {
         $output = '<h1 style="    color: #388E3C;
    font-weight: 500;
    margin-top: 38px;"><i class="dashicons dashicons-editor-help" style="
    font-size: 36px;
    margin-right: 20px;
    margin-top: -1px;"></i>Need Help?</h1>
<p style="
    font-family: georgia;
    font-size: 20px;
    font-style: italic;
    margin-bottom: 3px;
    line-height: 1.5;
    margin-top: 11px;
    color: #666;">Were bunch of passionate people that are dedicated towards helping our users. We will be happy to help you!</p>



         ';
      }
      return $output ;
    }

    /*
     *
     * ---> START SECTIONS
     *
     */

    Redux::setSection( $opt_name, array(
        'title' => __( 'AMP Sections', 'redux-framework-demo' ),
        'id'    => 'basic',
        'icon'  => 'el el-cogs',
        
    ) );


    Redux::setSection( $opt_name, array(
        'title'      => __( 'Genaral', 'redux-framework-demo' ),
        'id'         => 'opt-text-subsection',
        'subsection' => true,
        'fields'     => array(

             array(
                'id'       => 'opt-media',
                'type'     => 'media',
                'url'      => true,
                'title'    => __('Logo', 'redux-framework-demo'),
                'subtitle' => __('Upload a logo for the AMP version.', 'redux-framework-demo'),
                'desc'    => __('Recommend logo size is: 200x80', 'redux-framework-demo')
            ),
            array(
                'id'       => 'seomasternrj-custom-logo-dimensions',
                'title'    => __('Custom Logo Size', 'redux-framework-demo'),
                'type'     => 'switch',
                'default'  => 1,
            ),
             array(
                'id'       => 'opt-media-width',
                'type'     => 'text',
                'title'    => __('Logo Width', 'redux-framework-demo'),
                'desc'    => __('Default width is 200 pixels', 'redux-framework-demo'),
                'default' => '200',
                'required'=>array('seomasternrj-custom-logo-dimensions','=','1'),
            ),
             array(
                'id'       => 'opt-media-height',
                'type'     => 'text',
                'title'    => __('Logo Height', 'redux-framework-demo'),
                'desc'    => __('Default height is 70 pixels', 'redux-framework-demo'),
                'default' => '80',
                'required'=>array('seomasternrj-custom-logo-dimensions','=','1'),

            ),
             array(
                'id'       => 'amp-phone',
                'type'     => 'text',
                'title'    => __('Phone Number', 'redux-framework-demo'),
                'desc'    => __('00 0000 0000', 'redux-framework-demo'),
            ),
             array(
                'id'       => 'amp-email',
                'type'     => 'text',
                'title'    => __('Email', 'redux-framework-demo'),
                'desc'    => __('info@example.com', 'redux-framework-demo'),
            ),
             array(
                'id'       => 'amp-address',
                'type'     => 'text',
                'title'    => __('Address', 'redux-framework-demo'),
                'desc'    => __('Paste your address here', 'redux-framework-demo'),
            ),
           array(
               'id'        =>'amp-on-off-for-all-pages',
               'type'      => 'switch',
               'title'     => __('AMP on Pages', 'redux-framework-demo'),
               'subtitle'  => __('Enable or Disable AMP on all Pages', 'redux-framework-demo'),
               'default'   => 1,
               'desc'      => __( 'Re-Save permalink if you make changes in this option', 'redux-framework-demo' ),
            ),
          array(
               'id'       => 'amp-pages-meta-default',
               'type'     => 'select',
               'title'    => __( 'Individual AMP Page (Bulk Edit)', 'redux-framework-demo' ),
               'subtitle' => __( 'Allows you to Show or Hide AMP from All pages, so it can be changed individually later. This option will change the  Default value of AMP metabox in Pages', 'redux-framework-demo' ),
               'desc' => __( 'NOTE: Changes will overwrite the previous settings.', 'redux-framework-demo' ),
               'options'  => array(
                   'show' => __('Show by Default', 'redux-framework-demo' ),
                   'hide' => __('Hide by default', 'redux-framework-demo' ),
               ),
               'default'  => 'show',
               'required'=>array('amp-on-off-for-all-pages','=','1'),
          ),


      )
    ) );//END
    // Homepage Section
   Redux::setSection( $opt_name, array(
        'title'      => __( 'Homepage', 'redux-framework-demo' ),
        'id'         => 'amp-homepage-settings',
        'subsection' => true,
        'fields'     => array(
              array(
                    'id'       => 'seomasternrj-homepage-on-off-support',
                    'type'     => 'switch',
                    'title'    => __('Homepage Support', 'redux-framework-demo'),
                    'subtitle' => __('Enable/Disable Home page using this switch.', 'redux-framework-demo'),
                    'default'  => '1',
            ),
            array(
                'id'        =>'amp-frontpage-select-option',
                'type'      => 'switch',
                'title'     => __('Front Page', 'redux-framework-demo'),
                'default'   => 0,
                'subtitle'  => __('Custom AMP front page', 'redux-framework-demo'),
                'true'      => 'true',
                'false'     => 'false',
                'required'  => array('seomasternrj-homepage-on-off-support','=','1'),
            ),
            array(
                'id'       => 'amp-frontpage-select-option-pages',
                'type'     => 'select',
                'title'    => __('Select Page as Front Page', 'redux-framework-demo'),
                'required' => array('amp-frontpage-select-option', '=' , '1'),
                // Must provide key => value pairs for select options
                'data'     => 'page',
                'args'     => array(
                    'post_type' => 'page',
                    'posts_per_page' => 500
                ),
                'default'  => '2',
            ),
            array(
               'id'       => 'seomasternrj-title-on-front-page',
               'type'     => 'switch',
               'url'      => true,
               'title'    => __('Title on Static Front Page', 'redux-framework-demo'),
               'subtitle' => __('Enable/Disable display of title on the Static Front Page.', 'redux-framework-demo'),
               'default' => 0,
               'required' => array('amp-frontpage-select-option', '=' , '1'),
            ),
            array(
                'id'        =>'amp-on-off-support-for-non-amp-home-page',
                'type'      => 'switch',
                'title'     => __('Non-AMP HomePage link in Header and Logo', 'redux-framework-demo'),
                'subtitle'  => __('If you want users in header to go to non-AMP website from the Header, then you can enable this option', 'redux-framework-demo'),
                'default'   => 0,
            ),
            
            array(
                'id'       => 'slider_switch',
                'type'     => 'switch', 
                'title'    => __('Slider Switch', 'redux-framework-demo'),
                'subtitle' => __('Look, it\'s on!', 'redux-framework-demo'),
                'default'  => 0,
            ),
            
            array(
                'id'       => 'home_slider',
                'type'     => 'slides',
                'required' => array('slider_switch', '=' , '1'),
                'show' => array(
                        'title' => true,
                        'description' => true,
                        'url' => true              // <<========= that is what was asked at the top.
                    ),
                'title'    => __( 'Home Slider', 'redux-framework-demo' ),
                'subtitle' => __( 'Upload your slide image.', 'redux-framework-demo' ),
                'placeholder' => array(
                'title'           => __('Slider Title', 'redux-framework-demo'),
                'description'     => __('Slider Description', 'redux-framework-demo'),
                'url'           => __('Image Height', 'redux-framework-demo'),
                ),
                    ),


          )
        )
      );


    // AMP GTM SECTION
   Redux::setSection( $opt_name,    array(
      	        'title' => __('Analytics'),
      	        // 'icon' => 'el el-th-large',
      			    'desc'  => 'You can either use Google Tag Manager or Other Analytics Providers',
                'subsection' => true,
      	        'fields' =>
      	        	array(


                    array(
                        'id'       => 'amp-analytics-select-option',
                        'type'     => 'select',
                        'title'    => __( 'Analytics Type', 'redux-framework-demo' ),
                        'subtitle' => __( 'Select your Analytics provider.', 'redux-framework-demo' ),
                        'options'  => array(
                            '1' => __('Google Analytics', 'redux-framework-demo' ),
                        ),
                        'required' => array(
                          array('amp-use-gtm-option', '=' , '0'),
                        ),
                        'default'  => '1',
                    ),
                      array(
                          'id'       => 'ga-feild',
                          'type'     => 'text',
                          'title'    => __( 'Google Analytics', 'redux-framework-demo' ),
                          'required' => array(
                            array('amp-use-gtm-option', '=' , '0'),
                            array('amp-analytics-select-option', '=' , '1')
                          ),
                          'subtitle' => __( 'Enter your Google Analytics ID.', 'redux-framework-demo' ),
                          'desc'     => __('Example: UA-XXXXX-Y', 'redux-framework-demo' ),
                          'default'  => 'UA-XXXXX-Y',
                      ),

                      //GTM
                        array(
                            'id'       => 'amp-use-gtm-option',
                            'type'     => 'switch',
                            'title'    => __( 'Use Google Tag Manager', 'redux-framework-demo' ),
                            'subtitle' => __( 'Select your Analytics provider.', 'redux-framework-demo' ),
                            'default'  => 0,
                        ),
                        array(
              						'id'        	=>'amp-gtm-id',
              						'type'      	=> 'text',
              						'title'     	=> __('Tag Manager ID (Container ID)'),
              						'default'   	=> '',
              						'desc'	=> 'Eg: GTM-5XXXXXP',
                        //  'validate' => 'not_empty',
                          'required' => array(
                            array('amp-use-gtm-option', '=' , '1')
                          ),
              					),
              					array(
              						'id'        	=>'amp-gtm-analytics-type',
              						'type'      	=> 'text',
              						'title'     	=> __('Analytics Type'),
              						'default'   	=> '',
              						'desc'	=> 'Eg: googleanalytics',
                         // 'validate' => 'not_empty',
                          'required' => array(
                            array('amp-use-gtm-option', '=' , '1')
                          ),
              					),
              					array(
              						'id'        	=>'amp-gtm-analytics-code',
              						'type'      	=> 'text',
              						'title'     	=> __('Analytics ID'),
              						'default'   	=> '',
      						        'desc'	=> 'Eg: UA-XXXXXX-Y',
                          // 'validate' => 'not_empty',
                          'required' => array(
                          array('amp-use-gtm-option', '=' , '1')),
              					),

      				    )
          	)
   );


//code for fetching ctegories to show as a list in redux settings
   $categories = get_categories( array(
                                      'orderby' => 'name',
                                      'order'   => 'ASC'
                                      ) );
  $categories_array = array();
   if ( $categories ) :
   foreach ($categories as $cat ) {
     $cat_id = $cat->cat_ID;
     $key = "".$cat_id;
     //building assosiative array of ID-cat_name
     $categories_array[ $key ] = $cat->name;
    }
    endif;
    //End of code for fetching ctegories to show as a list in redux settings

    function seomasternrj_get_element_default_color() {
        $default_value = get_option('redux_builder_amp', true);
        $default_value = $default_value['amp-opt-color-rgba-colorscheme']['color'];
        if ( empty( $default_value ) ) {
          $default_value = '#333';
        }
      return $default_value;
    }

    // AMP Design SECTION
   Redux::setSection( $opt_name, array(
       'title'      => __( 'Design', 'redux-framework-demo' ),
       'desc'       => __( 'Put your custom css here'),
       'id'         => 'amp-design',
       'subsection' => true,
        'fields'     => array(
        array(
            'id'       => 'css_editor',
            'type'     => 'ace_editor',
            'title'    => __('Custom CSS', 'redux-framework-demo'),
            'subtitle' => __('You can customize the Stylesheet of the AMP version by using this option.', 'redux-framework-demo'),
            'mode'     => 'css',
            'theme'    => 'monokai',
            'desc'     => '',
            'default'  => "/******* Paste your Custom CSS in this Editor *******/"
        ),

   )

   ));

   // SEO SECTION
  Redux::setSection( $opt_name, array(
      'title'      => __( 'SEO', 'redux-framework-demo' ),
      'desc'       => __( '', 'redux-framework-demo'),
      'id'         => 'amp-seo',
      'subsection' => true,
       'fields'     => array(

           array(
               'id'       => 'seomasternrj-seo-meta-description',
               'type'     => 'switch',
               'title'     => __('Meta Description', 'redux-framework-demo'),
               'subtitle'     => __('The meta tag that displays in head', 'redux-framework-demo'),
               'default'  => 1
           ),

           array(
               'id'       => 'seomasternrj-seo-custom-additional-meta',
               'type'     => 'textarea',
               'title'    => __('Additional tags for Head section AMP page', 'redux-framework-demo'),
               'subtitle' => __('Adds additional Meta to the head section', 'redux-framework-demo', 'redux-framework-demo'),
               'desc' => __('Only link and meta tags allowed', 'redux-framework-demo'),
               'placeholder'  => "<!-- Paste your Additional HTML , that goes between <head> </head> tags -->"
           ),


           array(
                  'id' => 'seomasternrj-yoast-seo-sub-section',
                  'type' => 'section',
                  'title' => __('Yoast SEO Options', 'redux-framework-demo'),
                  'indent' => true
              ),

           array(
               'id'       => 'seomasternrj-seo-yoast-meta',
               'type'     => 'switch',
               'subtitle'     => __('Adds Social and Open Graph Meta Tags from Yoast', 'redux-framework-demo'),
               'title'    => __( 'Meta Tags from Yoast', 'redux-framework-demo' ),
               'default'  => '1'
           ),
           array(
               'id'       => 'seomasternrj-seo-yoast-description',
               'type'     => 'switch',
               'subtitle'     => __('Adds Yoast Custom description to ld+json for AMP page', 'redux-framework-demo'),
               'title'    => __( 'Yoast Description in ld+json', 'redux-framework-demo' ),
               'default'  => 1
           ),

           array(
                  'id' => 'seomasternrj-seo-index-noindex-sub-section',
                  'type' => 'section',
                  'title' => __('Advanced Index & No Index Options', 'redux-framework-demo'),
                  'indent' => true
              ),
           array(
               'id'       => 'seomasternrj-robots-archive-sub-pages-sitewide',
               'type'     => 'switch',
               'title'    => __('Archive subpages (sitewide)', 'redux-framework-demo'),
               'desc'  => "Such as /page/2 so on and so forth",
               'default' => 0,
               'on' => 'index',
               'off' => 'noindex'
           ),
           array(
               'id'       => 'seomasternrj-robots-archive-author-pages',
               'type'     => 'switch',
               'title'    => __('Author Archive pages', 'redux-framework-demo'),
               'default' => 0,
               'on' => 'index',
               'off' => 'noindex'

           ),
           array(
               'id'       => 'seomasternrj-robots-archive-date-pages',
               'type'     => 'switch',
               'title'    => __('Date Archive pages', 'redux-framework-demo'),
               'default' => 0,
               'on' => 'index',
               'off' => 'noindex'

           ),
           array(
               'id'       => 'seomasternrj-robots-archive-category-pages',
               'type'     => 'switch',
               'title'    => __('Categories', 'redux-framework-demo'),
               'default' => 0,
               'on' => 'index',
               'off' => 'noindex'
           ),
           array(
               'id'       => 'seomasternrj-robots-archive-tag-pages',
               'type'     => 'switch',
               'title'    => __('Tags', 'redux-framework-demo'),
               'default' => 0,
               'on' => 'index',
               'off' => 'noindex'
           ),


       )

  )

  );


    // Single Section
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Single', 'redux-framework-demo' ),
        'desc'       => __( 'Additional Options to control the look of Single', 'redux-framework-demo' ),
        'id'         => 'amp-single',
        'subsection' => true,
        'fields'     => array(
          // Social Icons ON/OFF
          array(
              'id'        => 'enable-single-social-icons',
              'type'      => 'switch',
              'title'     => __('Sticky Social Icons', 'redux-framework-demo'),
              'default'   => 0,
              'subtitle'  => __('Enable Social Icons in single', 'redux-framework-demo'),
          ),
          //deselectable next previous links
          array(
              'id'        => 'enable-single-next-prev',
              'type'      => 'switch',
              'title'     => __('Next-Previous Links', 'redux-framework-demo'),
              'default'   => 0,
              'subtitle'  => __('Enable Next-Previous links in single', 'redux-framework-demo'),
          ),
          // Related Post
	        array(
    		        'id'       => 'seomasternrj-single-select-type-of-related',
    		        'type'     => 'select',
    		        'title'    => __('Show Related Post from', 'redux-framework-demo'),
    		        'data'     => 'page',
                'subtitle' => __('select the type of related posts', 'redux-framework-demo'),
    		        'options'  => array(
    			        '1' => 'Tags',
    			        '2' => 'Categories'
    		        ),
               'default'  => '2',
	        ),
	        array(
    		        'id'       => 'seomasternrj-number-of-related-posts',
    		        'type'     => 'text',
    		        'title'    => __('Number of Related Post', 'redux-framework-demo'),
                'subtitle' => __('Type the number of related posts you need, Eg : 2', 'redux-framework-demo'),
    		        'validate' => 'numeric',
                'default'  => '3',
	        ),
        ),

    ) );

    // Social Section
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Social Media', 'redux-framework-demo' ),
        'id'         => 'amp-social',
        'desc'      => 'enable social share and your social profiels here',
        'subsection' => true,
        'fields'     => array(
           array(
              'id'     =>   'social-links',
              'title'  =>   'Social Links',
              'type'   =>   'switch',
              'default'   =>  0,
            ),
			
			array(
				'id'=>'single-social-link',
				'type' => 'multi_text',
				'title' => __('Social Media Link', 'redux-framework-demo'),
				'subtitle' => 'facebook,gplus,twitter,linkedin,instagram',
				//'validate' => 'not_empty',
				'required' => array('social-links', '=' , '1'),
				'desc' => __('profile Name, Profile Link', 'redux-framework-demo')
			),
			
			array(
              'id'        =>  'google_review',
              'type'      =>   'text',
              'title'     =>  'Google Review',
              'required' => array('social-links', '=' , '1'),
            ),

          // Facebook ON/OFF
          array(
              'id'        =>  'enable-single-facebook-share',
              'type'      =>  'switch',
              //'required'  => array('enable-single-social-icons', '=' , '1'),
              'title'     =>  __('Facebook', 'redux-framework-demo'),
              'default'   =>  0,
          ),

          array(
              'id'        =>  'amp-facebook-app-id',
              'type'      =>   'text',
              'title'     =>  'Facebook App ID',
              'required' => array('enable-single-facebook-share', '=' , '1'),
            ),


          // Twitter ON/OFF
          array(
              'id'        =>  'enable-single-twitter-share',
              'type'      =>  'switch',
              'title'     =>  __('Twitter', 'redux-framework-demo'),
              'default'   =>  0,
          ),
          // GooglePlus ON/OFF
          array(
              'id'        =>  'enable-single-gplus-share',
              'type'      =>  'switch',
              'title'     =>  __('GooglePlus', 'redux-framework-demo'),
              'default'   =>  0,
          ),
          // Email ON/OFF
          array(
              'id'        =>  'enable-single-email-share',
              'type'      =>  'switch',
              'title'     =>  __('Email', 'redux-framework-demo'),
              'default'   =>  1,
          ),
          // LinkedIn ON/OFF
          array(
              'id'        =>  'enable-single-linkedin-share',
              'type'      =>  'switch',
              'title'     =>  __('LinkedIn', 'redux-framework-demo'),
              'default'   =>  0,
          ),

        )
    ) );

    // Structured Data
    Redux::setSection( $opt_name, array(
        'title'      => __( 'Structured Data', 'redux-framework-demo' ),
        'id'         => 'opt-structured-data',
        'subsection' => true,
        'fields'     => array(
            array(
              'id'       => 'amp-structured-data-logo',
              'type'     => 'media',
              'url'      => true,
              'title'    => __('Default Structured Data Logo', 'redux-framework-demo'),
              'subtitle' => __('Upload the logo you want to show in Google Structured Data. ', 'redux-framework-demo'),
            ),
            array(
              'id'      => 'amp-structured-data-placeholder-image',
              'type'    => 'media',
              'url'     => true,
              'title'   => __('Default Post Image', 'redux-framework-demo'),
              'subtitle'    => __('Upload the Image you want to show as Placeholder Image.', 'redux-framework-demo'),
              'placeholder'  => 'when there is no featured image set in the post',
            ),
            array(
            'id'       => 'amp-structured-data-placeholder-image-width',
            'title'    => __('Default Post Image Width', 'redux-framework-demo'),
            'type'     => 'text',
            'placeholder' => '550',
            'subtitle' => 'Please don\'t add "PX" in the image size.',
            'default'  => '700'
            ),
            array(
              'id'       => 'amp-structured-data-placeholder-image-height',
              'title'    => __('Default Post Image Height', 'redux-framework-demo'),
              'type'     => 'text',
              'placeholder' => '350',
              'subtitle' => 'Please don\'t add "PX" in the image size.',
              'default'  => '550'
             ),
        )
    ) );

 

   // Translation Panel
           Redux::setSection( $opt_name, array(
               'title'      => __( 'Translation Panel', 'redux-framework-demo' ),
               'desc'       => __( 'Please translate the following words of page accordingly else default content is in English Language', 'redux-framework-demo' ),
               'id'         => 'amp-translator',
               'subsection' => true,
               'fields'     => array(
                   array(
                       'id'       => 'amp-translator-show-more-posts-text',
                       'type'     => 'text',
                       'title'    => __('Show more Posts', 'redux-framework-demo'),
                       'default'  => 'Show more Posts',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-show-previous-posts-text',
                       'type'     => 'text',
                       'title'    => __('Show previous Posts', 'redux-framework-demo'),
                       'default'  => 'Show previous Posts',
                       'placeholder'=>'write here'
                   ),

                   array(
                       'id'       => 'amp-translator-related-text',
                       'type'     => 'text',
                       'title'    => __('Related Post', 'redux-framework-demo'),
                       'default'  => 'Related Post',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-navigate-text',
                       'type'     => 'text',
                       'title'    => __('Navigate', 'redux-framework-demo'),
                       'default'  => 'Menu',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-on-text',
                       'type'     => 'text',
                       'title'    => __('On', 'redux-framework-demo'),
                       'default'  => 'On',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-next-text',
                       'type'     => 'text',
                       'title'    => __('Next', 'redux-framework-demo'),
                       'default'  => 'Next',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-previous-text',
                       'type'     => 'text',
                       'title'    => __('Previous', 'redux-framework-demo'),
                       'default'  => 'Previous',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-categories-text',
                       'type'     => 'text',
                       'title'    => __('Categories', 'redux-framework-demo'),
                       'default'  => 'Categories: ',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-tags-text',
                       'type'     => 'text',
                       'title'    => __('Tags', 'redux-framework-demo'),
                       'default'  => 'Tags: ',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-by-text',
                       'type'     => 'text',
                       'title'    => __('By', 'redux-framework-demo'),
                       'default'  => 'By',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-published-by',
                       'type'     => 'text',
                       'title'    => __('Published by', 'redux-framework-demo'),
                       'default'  => 'Published by',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-in-designthree',
                       'type'     => 'text',
                       'title'    => __('in', 'redux-framework-demo'),
                       'default'  => 'in',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-view-comments-text',
                       'type'     => 'text',
                       'title'    => __('View Comments', 'redux-framework-demo'),
                       'default'  => 'View Comments',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-leave-a-comment-text',
                       'type'     => 'text',
                       'title'    => __('Leave a Comment', 'redux-framework-demo'),
                       'default'  => 'Leave a Comment',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-at-text',
                       'type'     => 'text',
                       'title'    => __('at', 'redux-framework-demo'),
                       'default'  => 'at',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-says-text',
                       'type'     => 'text',
                       'title'    => __('says', 'redux-framework-demo'),
                       'default'  => 'says',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-Edit-text',
                       'type'     => 'text',
                       'title'    => __('Edit', 'redux-framework-demo'),
                       'default'  => 'Edit',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-ago-date-text',
                       'type'     => 'text',
                       'title'    => __('ago', 'redux-framework-demo'),
                       'default'  => 'ago',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-archive-cat-text',
                       'type'     => 'text',
                       'title'    => __('Category (archive title)', 'redux-framework-demo'),
                       'default'  => 'Category: ',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-archive-tag-text',
                       'type'     => 'text',
                       'title'    => __('Tag (archive title)', 'redux-framework-demo'),
                       'default'  => 'Tag: ',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-show-more-text',
                       'type'     => 'text',
                       'title'    => __('View More Posts (Widget Button)', 'redux-framework-demo'),
                       'default'  => 'View More Posts',
                       'placeholder'=>'write here'
                   ),
                    array(
                       'id'       => 'amp-translator-next-read-text',
                       'type'     => 'text',
                       'title'    => __('Next Read', 'redux-framework-demo'),
                       'default'  => 'Next Read: ',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-search-text',
                       'type'     => 'text',
                       'title'    => __(' You searched for: ', 'redux-framework-demo'),
                       'default'  => ' You searched for: ',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id'       => 'amp-translator-search-no-found',
                       'type'     => 'text',
                       'title'    => __(' It seems we can\'t find what you\'re looking for. ', 'redux-framework-demo'),
                       'default'  => ' It seems we can\'t find what you\'re looking for. ',
                       'placeholder'=>'write here'
                   ),
                   array(
                       'id' => 'design-3-search-subsection',
                       'type' => 'section',
                       'title' => __('Search bar Translation Text', 'redux-framework-demo'),
                       'indent' => true,
                   ),
                   array(
                      'id'       => 'seomasternrj-search-placeholder',
                      'type'     => 'text',
                      'title'    => __('Type Here', 'redux-framework-demo'),
                      'default'  => 'Type Here',
                      'desc' => 'This is the text that gets shown in for Search Box',
                      'placeholder'=>'write here',

                  ),
                  array(
                     'id'       => 'seomasternrj-search-label',
                     'type'     => 'text',
                     'title'    => __('Type your search query and hit enter', 'redux-framework-demo'),
                     'desc' => 'This is the text that gets shown above Search Box',
                     'default'  => 'Type your search query and hit enter: ',
                     'placeholder'=>'write here',

                 ),
                    
               )
           ) );






// Advance Settings SECTION
Redux::setSection( $opt_name, array(
   'title'      => __( 'Advance and Footer Settings', 'redux-framework-demo' ),
   'desc'       => __( 'This section has Advance settings'),
   'id'         => 'amp-advance',
   'subsection' => true,
   'fields'     => array(

                    array(
                        'id'       => 'seomasternrj-homepage-on-off-support',
                        'type'     => 'switch',
                        'title'    => __('Homepage Support', 'redux-framework-demo'),
                        'subtitle' => __('Enable/Disable Home page using this switch.', 'redux-framework-demo'),
                        'default'  => '0'
                    ),
                    array(
                        'id'       => 'seomasternrj-archive-support',
                        'type'     => 'switch',
                        'title'    => __('Archive page Support', 'redux-framework-demo'),
                        'subtitle' => __('Enable/Disable Archive pages using this switch.', 'redux-framework-demo'),
                        'default'  => '0'
                    ),
                    array(
                        'id'       => 'amp-header-text-area-for-html',
                        'type'     => 'editor',
                        'title'    => __('Enter HTML in Header', 'redux-framework-demo'),
                        'subtitle' => __('please enter markup that is AMP validated', 'redux-framework-demo'),
                        'desc' => __('check your markup here (enter markup between HEAD tag) : https://validator.ampproject.org/', 'redux-framework-demo'),
                        'default'   => ''
                    ),
                     array(
                        'id'       => 'footer-extra-code',
                        'type'     => 'editor',
                        'title'    => __('Footer Extra Code', 'redux-framework-demo'),
                        'subtitle' => __('Footer Extra Code', 'redux-framework-demo'),
                        'desc' => __('check your markup here (enter markup between BODY tag) : https://validator.ampproject.org/', 'redux-framework-demo'),
                    ),
                    array(
                        'id'       => 'interlink_switch',
                        'type'     => 'switch', 
                        'title'    => __('Interlink Switch', 'redux-framework-demo'),
                        'subtitle' => __('Look, it\'s on!', 'redux-framework-demo'),
                        'default'  => false,
                    ),
                    array(
                        'id'=>'interlinks',
                        'type' => 'multi_text',
                        'title' => __('Interlinks', 'redux-framework-demo'),
                        'required' => array('interlink_switch', '=' , '1'),
                        'subtitle' => 'Link Title, Link url',
                        //'validate' => 'not_empty',
                        'desc' => __('Link Title, Link url', 'redux-framework-demo')
                    ),
       
                    array(
                        'id'       => 'map_switch',
                        'type'     => 'switch', 
                        'title'    => __('Map Switch', 'redux-framework-demo'),
                        'subtitle' => __('Look, it\'s on!', 'redux-framework-demo'),
                        'default'  => false,
                    ),
       
					array(
                        'id'       => 'footer_map_img',
                        'type'     => 'media',
                        'url'      => true,
                        'title'    => __('Footer Map Image', 'redux-framework-demo'),
                        'required' => array('map_switch', '=' , '1'),
                        'subtitle' => __('Upload Map Image', 'redux-framework-demo'),
                    ),
                    array(
                        'id'       => 'footer_map_url',
                        'type'     => 'text',
                        'title'    => __('Footer Map URL', 'redux-framework-demo'),
                        'required' => array('map_switch', '=' , '1'),
                        'subtitle' => __('Input Here Google Map URL', 'redux-framework-demo'),
                    ),
                    array(
                       'id'       => 'amp-translator-footer-text',
                       'type'     => 'editor',
                       'title'    => __('Footer', 'redux-framework-demo'),
                       'default'  => '© 2017 BeLocal Today. All Rights Reserved. Digital Transformation by <a target="_blank" href="https://belocal.today/">BeLocal Today</a>',
                       'placeholder'=>'write here',
                        'subtitle' => __('please enter markup that is AMP validated', 'redux-framework-demo'),
                        'desc' => __('check your markup here (enter markup between BODY tag) : https://validator.ampproject.org/'),
                   ),
)
) );




  Redux::setSection( $opt_name, array(
        'title' => __( 'Analytics Section', 'redux-framework-demo' ),
        'id'    => 'nrj_analytics',
        'desc'  => __( '', 'redux-framework-demo' ),
        'icon'  => 'el el-signal',
        
    ) );

 Redux::setSection( $opt_name, array(
        'title'      => __( 'Analytics Code Sec', 'redux-framework-demo' ),
        'id'         => 'analytics_code_sec',
        'subsection' => true,
        'fields'     => array(
          array(
          'id'       => 'analytics-switch',
          'type'     => 'switch', 
          'title'    => __('Analytics Switch', 'redux-framework-demo'),
          'subtitle' => __('If you want Analytics, please switch on this button', 'redux-framework-demo'),
          'default'  => false,
        ),

            array(
                'id'       => 'analytics_id',
                'required' => array('analytics-switch', '=' , '1'),
                'type'     => 'text',
                'title'    => __( 'Analytics ID', 'redux-framework-demo' ),
                'subtitle' => __( 'Paste your  id here (UA-xxxxxxxx-x).', 'redux-framework-demo' ),
            ),

         array(
          'id'       => 'tagmanager-switch',
          'type'     => 'switch', 
          'title'    => __('Tag Manager Switch', 'redux-framework-demo'),
          'subtitle' => __('If you want Tag Manger, please switch on this button', 'redux-framework-demo'),
          'default'  => false,
        ),

        array(
            'id'       => 'google_tag_id',
            'required' => array('tagmanager-switch', '=' , '1'),
            'type'     => 'text',
            'title'    => __( ' Google Tag Manager ID', 'redux-framework-demo' ),
            'subtitle' => __( 'Paste your id here (GTM-xxxxxxx).', 'redux-framework-demo' ),
        ),

        )
    ) );

Redux::setSection( $opt_name, array(
        'title' => __( 'Schema Section', 'redux-framework-demo' ),
        'id'    => 'nrj_schema',
        'desc'  => __( '', 'redux-framework-demo' ),
        'icon'  => 'el el-idea',
        
    ) );


 Redux::setSection( $opt_name, array(
        'title'      => __( 'Schema Code Sec', 'redux-framework-demo' ),
        'id'         => 'schema_code_sec',
        'subsection' => true,
        'fields'     => array(
        array(
          'id'       => 'schema-switch',
          'type'     => 'switch', 
          'title'    => __('Schema Switch', 'redux-framework-demo'),
          'subtitle' => __('If you want schema, please switch on this button', 'redux-framework-demo'),
          'default'  => false,
        ),
			array(
				'id'       => 'schema_email',
				'type'     => 'text',
				'title'    => __('Schema Email', 'redux-framework-demo'),
				'validate' => 'email',
        'required' => array('schema-switch', '=' , '1'),
			),
			array(
				'id'       => 'schema_phone',
				'type'     => 'text',
				'title'    => __('Schema Phone', 'redux-framework-demo'),
        'required' => array('schema-switch', '=' , '1'),
			),
			array(
				'id'       => 'schema_streetaddress',
				'type'     => 'text',
				'title'    => __('Schema Street Address', 'redux-framework-demo'),
        'required' => array('schema-switch', '=' , '1'),
			),
			array(
				'id'       => 'schema_addresslocality',
				'type'     => 'text',
				'title'    => __('Schema Address Locality', 'redux-framework-demo'),
        'required' => array('schema-switch', '=' , '1'),
			),
			array(
				'id'       => 'schema_addressregion',
				'type'     => 'text',
				'title'    => __('Schema Address Region', 'redux-framework-demo'),
        'required' => array('schema-switch', '=' , '1'),
			),
			array(
				'id'       => 'schema_postalcode',
				'type'     => 'text',
				'title'    => __('Schema Postal Code', 'redux-framework-demo'),
        'required' => array('schema-switch', '=' , '1'),
			),
			

			array(
                'id'       => 'business_schema',
                'type'     => 'slides',
                'show' => array(
                        'title' => true,
                        'description' => false,
                        'url' => true              
                    ),
                'title'    => __( 'Business Schema', 'redux-framework-demo' ),
                'subtitle' => __( 'Business type schema.', 'redux-framework-demo' ),
                'required' => array('schema-switch', '=' , '1'),
				'placeholder' => array(
				'title'           => __('Schema Type', 'redux-framework-demo'),
				'description'     => __('Name', 'redux-framework-demo'),
				'url'             => __('Name', 'redux-framework-demo'),
				),
            ),
			
			
			

        )
    ) );




Redux::setSection( $opt_name, array(
        'title' => __( 'Review Snippet Section', 'redux-framework-demo' ),
        'id'    => 'nrj_reveiw_snippet',
        'desc'  => __( '', 'redux-framework-demo' ),
        'icon'  => 'el el-comment-alt',
        
    ) );


 Redux::setSection( $opt_name, array(
        'title'      => __( 'Review Snippet Section', 'redux-framework-demo' ),
        'id'         => 'review-snippet_sec',
        'subsection' => true,
        'fields'     => array(
        array(
          'id'       => 'review_snippet_switch',
          'type'     => 'switch', 
          'title'    => __('Review Snippet Switch', 'redux-framework-demo'),
          'subtitle' => __('If you want Review Snippet, please switch on this button', 'redux-framework-demo'),
          'default'  => false,
        ),
			array(
				'id'       => 'review_product_name',
				'type'     => 'text',
				'title'    => __('Review Product Name', 'redux-framework-demo'),
        		'required' => array('review_snippet_switch', '=' , '1'),
			),
			array(
				'id'       => 'review_rating_value',
				'type'     => 'text',
				'title'    => __('Review Rating Value', 'redux-framework-demo'),
        'required' => array('review_snippet_switch', '=' , '1'),
			),
			array(
				'id'       => 'review_rating_count',
				'type'     => 'text',
				'title'    => __('Review Rating Count', 'redux-framework-demo'),
                'required' => array('review_snippet_switch', '=' , '1'),
			),

			array(
	          'id'       => 'single_review_snippet_switch',
	          'type'     => 'switch', 
	          'title'    => __('Single Review Snippet Switch', 'redux-framework-demo'),
	          'subtitle' => __('If you want Single Review Snippet, please switch on this button', 'redux-framework-demo'),
	          'default'  => false,
	        ),

			array(
                'id'       => 'single_client_review',
                'type'     => 'slides',
                'show' => array(
                        'title' => true,
                        'description' => true,
                        'url' => true,           
                    ),
                
                'title'    => __( 'Single Client Reivew', 'redux-framework-demo' ),
                'subtitle' => __( 'Client review', 'redux-framework-demo' ),
                'required' => array('single_review_snippet_switch', '=' , '1'),
				'placeholder' => array(
				'title'           => __('Author', 'redux-framework-demo'),
				'description'     => __('Review Description', 'redux-framework-demo'),
				'url'             => __('Review Rating Value', 'redux-framework-demo'),
				),
            ),
        )
    ) );


/*
* <--- END SECTIONS
*/
