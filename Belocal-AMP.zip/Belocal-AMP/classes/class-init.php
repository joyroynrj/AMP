<?php 

if ( ! class_exists( 'seomasternrj_Loader', false ) ) {

	class seomasternrj_Loader {


		public function __construct() {
			$this->load_required_files();
		}

		public function load_required_files() {

			require SEOMASTERNRJ_PLUGIN_DIR . '/templates/features.php';

		}
	}
}
?>